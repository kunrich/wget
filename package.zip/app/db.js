const fs=require("fs");

function R938(mydb,key){
	this.key=key;
	if(key.hasOwnProperty(0))this.id=key[0];
	else console.log('R938: is not set key-id');

	
	if(!fs.existsSync('R938'))fs.mkdirSync('R938');
	this.mydb='R938/'+mydb+'.R938';
	this.length=0;
	this.db={};
	this.update();
}

R938.prototype.db={};
R938.prototype.length=0;
R938.prototype.row='~';
R938.prototype.cell='`';
R938.prototype._row="&#x7E;";
R938.prototype._cell="&#x60;";
R938.prototype.cc=function(a){
	return a.toString().replace(RegExp(this.row,'g'),this._row).replace(RegExp(this.cell,'g'),this._cell);
};

R938.prototype.update=function(){
	if(fs.existsSync(this.mydb)){
		let data='';
		try{
			data=fs.readFileSync(this.mydb,{encoding:'utf8'});
		}catch(err){
			console.log('R938: Error readFileSync');
		}
		if(data!='')this.db=this.der938(data);
	}else{
		fs.writeFileSync(this.mydb,'',{encoding:'utf8'});
	}
};

R938.prototype.sync=function(a){
	try{
		fs.writeFileSync(this.mydb,this.enr938(this.db),{encoding:'utf8'});
		if(a==1)this.update();
		return 1;
	}catch(err){
		return 0;
	}
};

R938.prototype.der938=function(a){
	let b=a.split(this.row),dbs={},len=0;
	if(this.key.hasOwnProperty(0)){
		for(x in b){
			len++;
			let c=b[x].split(this.cell);
			if(c.length>0){
				dbs[c[0]]={};
				for(i in this.key)
					dbs[c[0]][this.key[i]]=c.hasOwnProperty(i)?c[i]:"";
			}
		}
	}
	this.length=len;
	return dbs;
};

R938.prototype.enr938=function(a){
	let dbs='',len=0;
	for(x in a){
		len++;
		let qw='';
		for(i in this.key)
			qw+=(qw==''?'':this.cell)+(a[x].hasOwnProperty(this.key[i])?a[x][this.key[i]]:'');
		dbs+=(dbs==''?'':this.row)+qw;
	}
	this.length=len;
	return dbs;
};

R938.prototype.number=function(str){
	if(typeof str!="string"&&typeof str!="number")return 0;
	return !isNaN(str)&&!isNaN(parseFloat(str));
};

R938.prototype.enregex=function(str){
	if(typeof str!='string'||str.length<1)return '';
	var s=["-","[","]","/","{","}","(",")","*","+","?",".","\\","^","$","|"];
    return str.toString().replace(new RegExp('['+s.join('\\')+']','g'),"\\$&");
};

R938.prototype.inarray=function(str,obj){
	let reg=new RegExp(this.enregex(str),"i");
    for(x in obj)
		if(obj[x]==str||(obj[x].length==str.length&&obj[x].match(reg)))
			return 1;
    return 0;
};

R938.prototype.asarray=function(str,obj){
	let reg=[];
	str.forEach((a,b)=>{
		reg[b]=new RegExp(this.enregex(a),"i");
	});
	for(x in str){
		let ch=0;
		obj.forEach((a)=>{
			if(a==str[x]||(a.length==str[x].length&&a.match(reg[x])))ch=1;
		});
		if(!ch)return 0;
	}
    return 1;
};

R938.prototype.add=function(value){
	if(value.hasOwnProperty(this.id)&&
	!this.db.hasOwnProperty(this.cc(value[this.id]))&&
	(value[this.id]+'').search(/[\~\`]/)==-1){
		let id=this.cc(value[this.id]);
		this.db[id]={};
		for(i in this.key){
			let b=this.key[i];
			this.db[id][b]=value.hasOwnProperty(b)?this.cc(value[b]):'';
		}
		return this.sync();
	}
	return 0;
};

R938.prototype.adds=function(value){
	for(x in value){
		if(value[x].hasOwnProperty(this.id)&&!this.db.hasOwnProperty(this.cc(value[x][this.id]))&&(value[x][this.id]+'').search(/[\~\`]/)==-1){
			let id=this.cc(value[x][this.id]);
			this.db[id]={};
			for(i in this.key){
				let b=this.key[i];
				this.db[id][b]=value[x].hasOwnProperty(b)?this.cc(value[x][b]):'';
			}
		}else return 0;
	}
	return this.sync();
};

R938.prototype.set=function(key,value){
	if(this.db.hasOwnProperty(key)){
		let id=0;
		for(i in value){
			if(i==this.id&&(this.db.hasOwnProperty(this.cc(value[i]))||(value[i]+'').search(/[\~\`]/)!=-1)){
				return 0;
			}else if(this.db[key].hasOwnProperty(i)){
				if(i==this.id)id=1;
				this.db[key][i]=this.cc(value[i]);
			}
		}
		return this.sync(id);
	}
	return 0;
};
R938.prototype.sets=function(value){
	let id=0;
	for(x in value){
		if(this.db.hasOwnProperty(x)){
			for(i in value[x]){
				if(i==this.id&&(this.db.hasOwnProperty(this.cc(value[x][i]))||(value[x][i]+'').search(/[\~\`]/)!=-1)){
					return 0;
				}else if(this.db[x].hasOwnProperty(i)){
					if(i==this.id)id=1;
					this.db[x][i]=this.cc(value[x][i]);
				}
			}
		}else return 0;
	}
	return this.sync(id);
};

R938.prototype.one=function(key){
	return this.db.hasOwnProperty(key)?this.db[key]:0;
};

R938.prototype.show=function(){
	return this.db;
};

R938.prototype.get=function(code,by,sort,no,all){
	let q='',key={},m='',val=[],xdb={
		db:[],
		length:0
	};
	for(x in this.key)key[this.key[x]]=this.key[x];
	
	for(x in code){
		let c=code[x];
		if(typeof c=='object'&&c.length>=3&&key.hasOwnProperty(c[0])){
			let k=c[0],s=c[1],v=this.cc(c[2]);
			val[val.length]=v;
			let id=val.length-1;
			
			if(s=='='){
				q+=(q==''?'':m)+'(r["'+k+'"]==val['+id+'])';
			}else if(s=='!'){
				q+=(q==''?'':m)+'(r["'+k+'"]!=val['+id+'])';
			}else if(s=='#'){
				var ts=this.enregex(val[id]);
				if(ts=='')return xdb;
				val[id]=new RegExp(ts,"i");
				q+=(q==''?'':m)+'(r["'+k+'"].match(val['+id+'])==null)';
			}else if(s=='%'){
				var ts=this.enregex(val[id]);
				if(ts=='')return xdb;
				val[id]=new RegExp(ts,"i");
				q+=(q==''?'':m)+'(r["'+k+'"].match(val['+id+'])!=null)';
			}else if(s=='>'){
				q+=(q==''?'':m)+'(this.number(r["'+k+'"])&&r["'+k+'"]*1>val['+id+'])';
			}else if(s=='<'){
				q+=(q==''?'':m)+'(this.number(r["'+k+'"])&&r["'+k+'"]*1<val['+id+'])';
			}else if(s=='/'){
				q+=(q==''?'':m)+'(this.inarray(val['+id+'],r["'+k+'"].split("\\n")))';
			}else if(s=='?'){
				val[id]=val[id].split('|');
				q+=(q==''?'':m)+'(this.asarray(val['+id+'],r["'+k+'"].split("\\n")))';
			}else if((s=s.match(/\<(.*)\>/))!=null){
				if(!this.number(s[1]))return xdb;
				var ts=this.enregex(val[id]);
				if(ts=='')return xdb;
				val[id]=new RegExp(ts,"i");
				q+=(q==''?'':m)+'(r["'+k+'"]['+s[1]+']&&r["'+k+'"]['+s[1]+'].match(val['+id+'])!=null)';
			}
			
			m=c.hasOwnProperty(3)?(c[3]=='&'?'&&':'||'):'&&';
		}else return xdb;
	}
	
	if(q=='')return xdb;
	for(x in this.db){
		let r=this.db[x],uid=x;
		eval('if('+q+'){xdb.db[xdb.db.length]=this.db[uid];xdb.length++;}');
	}
	if(typeof by=="string"&&key.hasOwnProperty(by)){
		sort='xa.charCodeAt(i)>xb.charCodeAt(i)?'+(sort?'-1:1':'1:-1');
		xdb.db=xdb.db.sort((a,b)=>{
			let xa=a[by],xb=b[by],i=0,len=xa.length>xb.length?xb.length:xa.length;
			do{
				if(xa.charCodeAt(i)==xb.charCodeAt(i))i++;
				else return eval(sort);
			}while(len>i);
		});
	}
	if(typeof no=='number'&&typeof all=='number'&&xdb.length>all)
		xdb.db=xdb.db.slice((no-1)*all,no*all);
	
	return xdb;
};

R938.prototype.search=function(id,as,val){
	let i=this.get([
		[id,as,val]
	]);
	if(i.length==0)return 0;
	else return i.db[0];
};

R938.prototype.has=function(key){
	return this.db.hasOwnProperty(key);
};


R938.prototype.remove=function(key){
	if(this.db.hasOwnProperty(key)){
		delete this.db[key];
		return this.sync();
	}
	return 0;
};

R938.prototype.removes=function(key){
	for(x in key){
		if(this.db.hasOwnProperty(key[x]))delete this.db[key[x]];
		else return 0;
	}
	return this.sync();
};

R938.prototype.drop=function(){
	this.db={};
	return this.sync();
};

module.exports=R938;