let fs=require('fs'),
crypto=require('crypto');

module.exports=class{
	#add={
		users:{},
		url:'',
		_check:1,
		_lenall:0,
		_block:0,
		_length:0,
		_rawhead:'',
		size:0,
		senddata:0,
		sendcode:200,
		status:1,
		method:'close',
		powered:'R938/6.0',
		log:function(txt){
			let load=this.contime((new Date()).getTime()-this.time),ms='\x1b[33m';
			
			ms+=this.method.toUpperCase();
			if(ms.length<12)ms+=Array(13-ms.length).join(' ');
			
			ms+='\x1b[37m'+load;
			if(ms.length<24)ms+=Array(25-ms.length).join(' ');

			ms+='\x1b[32m'+this.bytes(this.senddata);
			if(ms.length<36)ms+=Array(37-ms.length).join(' ');

			ms+='\x1b[36m'+this.bytes(this.size);
			if(ms.length<48)ms+=Array(49-ms.length).join(' ');

			ms+='\x1b['+(typeof txt=='string'?'31m'+txt:'32mok');
			if(ms.length<61)ms+=Array(62-ms.length).join(' ');

			ms+='\x1b[37m'+this.ip().substr(0,14);
			if(ms.length<80)ms+=Array(81-ms.length).join(' ');

			ms+='\x1b[37m'+this.url;
			console.log(ms);
			ms='';
			
			this.size=0;
			this.senddata=0;
			this.time=(new Date()).getTime();
		},
		ip:function(){
			if(typeof this.head['cf-connecting-ip']=='string')
				return this.head['cf-connecting-ip'];
			else if(typeof this.head['x-forwarded-for']=='string')
				return this.head['x-forwarded-for'].split(',')[0];
			else
				return this.remoteAddress;
		},
		scode:function(code){
			this.sendcode=code;
			return this;
		},
		shead:function(key,val){
			this.sendhead[key.toLowerCase()]=val;
			return this;
		},
		sshead:function(obj){
			for(let x in obj)
				this.sendhead[x.toLowerCase()]=obj[x];
			return this;
		},
		headwrite:function(c,h){
			if(!this.status)return 0;
			if(typeof c=='number')this.scode(c);
			if(typeof h=='object')this.sshead(h);
			if(typeof this.sendhead['content-type']=='undefined'&&this.sendhead.upgrade!='websocket')
				this.sendhead['content-type']='text/html; charset=UTF-8';
			if(typeof this.sendhead.connection=='undefined')
				this.sendhead['connection']='keep-alive';
			if(typeof this.sendhead['x-frame-options']=='undefined')
				this.sendhead['x-frame-options']='DENY';
			
			this.sendhead['x-powered-by']=this.powered;
			
			let head='',code=this.sendcode,txtcode={
				101:'Switching Protocols',
				200:'OK',
				206:'Partial Content',
				400:'Bad Request',
				401:'Unauthorized',
				403:'Forbidden',
				404:'Not Found',
				408:'Request Timeout',
				411:'Length Required',
				415:'Unsupported Media Type',
				
				502:'Bad Gateway',
				504:'Gateway Timeout',
				
			}[code];
			for(let x in this.sendhead)
				head+=x+': '+this.sendhead[x]+'\r\n';
			this.write(Buffer.from('HTTP/1.1 '+code+' '+txtcode+'\r\n'+head+'\r\n'));
		},
		sendend:function(data,encode){
			if(!this.status)return 0;
			this.headwrite();
			data=Buffer.from(data);
			this.end(
				data,
				typeof encode=='undefined'?'utf8':encode
			);
			this.status=0;
			this.senddata=data.length;
			this.log();
		},
		wwwform:function(data){
			if(typeof data=='object')
				data=new TextDecoder('utf8').decode(data);
			var db={};
			for(let x of data.split('&')){
				var abc=x.search('='),name='',val='';
				if(abc==-1){
					name=x.trim();
					val='';
				}else{
					name=x.substring(0,abc).trim();
					val=decodeURIComponent(x.substr(abc+1));
				}
				if(typeof db[name]=='undefined')db[name]=[val];
				else db[name][db[name].length]=val;
			}
			return db;
		},
		formdata:function(buf,key){
			buf=Buffer.concat([Buffer.from('\r\n'),buf]);
			key='\r\n--'+key;

			let i=0,z=0,c=1,db={},l=key.length+2;
			while(c){
				z=buf.indexOf(key,i)+l;
				i=buf.indexOf(key,z);
				if(i>0){
					var b=buf.slice(z,i),abc;
					var name=' name="';
					var fname=b.indexOf(name)+name.length;
					name=b.slice(fname,b.indexOf('"',fname));
					
					var data='\r\n\r\n';
					data=b.slice(b.indexOf(data)+data.length);
					
					
					var file=' filename="';
					var ffile=b.indexOf(file);
					if(ffile!=-1){
						ffile+=file.length;
						file=b.slice(ffile,b.indexOf('"',ffile));
						
						var type='Content-Type: ';
						var ftype=b.indexOf(type)+type.length;
						type=b.slice(ftype,b.indexOf('\r\n',ftype)).toString();
						abc={
							name:file.toString(),
							type:type,
							data:data
						};
					}else{
						abc=new TextDecoder('utf8').decode(data);
					}
					
					if(typeof db[name]=='undefined')db[name]=[abc];
					else db[name][db[name].length]=abc;
					
				}else c=0;
			}
			return db;
		},
		sendwrite:function(data,encode){
			if(!this.status)return 0;
			let opcode=0x2;
			if(!Buffer.isBuffer(data)){
				if(typeof data=='string')opcode=0x1;
				data=Buffer.from(data);
			}
			let size=data.length,buffer;
			if(size<=125){
				buffer=Buffer.alloc(size+2+0);            
				buffer.writeUInt8(0x80|opcode,0);
				buffer.writeUInt8(size,1);
				data.copy(buffer,2);
			}else if(size<=65535){
				buffer=Buffer.alloc(size+2+2);            
				buffer.writeUInt8(0x80|opcode,0);
				buffer.writeUInt8(126,1);
				buffer.writeUInt16BE(size,2);
				data.copy(buffer,4);
			}else{
				buffer=Buffer.alloc(size+2+8);            
				buffer.writeUInt8(0x80|opcode,0);
				buffer.writeUInt8(127,1);
				buffer.writeUInt32BE(0,2);
				buffer.writeUInt32BE(size,6);
				data.copy(buffer,10);
			}
			this.write(buffer,typeof encode=='undefined'?'utf8':encode);
		},
		cancel:function(){
			if(!this.status)return 0;
			this.log('cancel');
			if(typeof this.stop=='function')this.stop();
			this.destroy();
			this.cancel=function(){};
		},
		error:function(code){
			if(!this.status)return 0;
			let data;
			if(typeof code!='number')code=404;
			if(this.method=='post')this.shead('content-type','application/json; charset=UTF-8');
			this.headwrite(code);
			if(this.method=='post'||this.method=='websocket')
				data=Buffer.from(JSON.stringify({status:code}));
			else{
				if(typeof this.page_err=='function'){
					data=Buffer.from(this.page_err(code));
				}else data=Buffer.from('<h1>error '+code+'</h1>');
			}
			this.end(data,'utf8');
			this.senddata=data.length;
			this.log('error');
		},
		usecookie:function(){
			try{
				var ck={},h=this.head.cookie;
				if(typeof h=='string'){
					h=h.split(';').forEach((a)=>{
						let name=a.substring(0,a.search('=')).trim();
						ck[name]=decodeURIComponent(a.substr(a.search('=')+1));
					});
					this.cookie=ck;
				}else this.cookie={};
				return ck;
			}catch(err){
				return {};
			}
		},
		scookie:function(name,value,op){
			var ck=name+'='+encodeURIComponent(value);
			if(typeof op=='object'){
				for(let x in op){
					var u='';
					if(op[x]!='')u='='+op[x];
					ck+='; '+x+u;
				}
			}
			this.shead('set-cookie',ck);
		},
		rcookie:function(name){
			this.shead('set-cookie',name+'=; Max-Age=-1');
		},
		u:function(a,b){
			let i=this.queue;
			if(i.hasOwnProperty(a)){
				i=i[a];
				return i.hasOwnProperty(b)?i[b]:i[i.length-1];
			}else return undefined;
		},
		contime:function(t){
			if(t>=86400000)t=(t/86400000).toFixed()+"d";
			else if(t>=3600000)t=(t/3600000).toFixed()+"hr";
			else if(t>=60000)t=(t/60000).toFixed()+"min";
			else if(t>=1000)t=(t/1000).toFixed()+'s';
			else if(t>=1)t=t+"ms";
			else t="0ms";
			return t
		},
		bytes:function(b){
			if(b>=1073741824)b=(b/1073741824).toFixed()+"g";
			else if(b>=1048576)b=(b/1048576).toFixed()+"m";
			else if(b>=1024)b=(b/1024).toFixed()+"k";
			else if(b>=1)b=b;
			else b="0";
			return b+"b"
		}
	}
	#path={}
	#referer={}
	#domain={}
	#maxdata=2e6
	#maxurl=100
	#timeout=3e4
	#maxpath=6
	#maxsocket=10
	#method={
		get:1,
		post:1,
		websocket:1,
	}
	#has(val,type,turn){
		if(typeof type=='undefined')type='string';
		if(typeof turn=='undefined')turn='';
		return typeof val==type?val:turn;
	}
	#is(val){
		return typeof val!='undefined';
	}
	#callback(req){
		let nm=this.#path['!'+req.method];
		if(typeof nm!='undefined'){
			if(typeof nm[req.url]=='function'){
				nm=nm[req.url];
			}else{
				let path=req.url.split("/").slice(1),i=0;
				if(path.length>this.#maxpath)
					return req.error(411);
				path.forEach((a,b)=>{path[b]=decodeURIComponent(a)});
				
				for(let x of path){
					if(typeof nm[x]!='undefined'){
						nm=nm[x];
					}else{
						if(typeof nm['*']!='undefined'){
							req.key['_path']=path.slice(i,path.length).join('/');
							nm=nm['*'];
							break;
						}else{
							if(nm.hasOwnProperty(':')){
								req.key[nm.__key]=x;
								nm=nm[':'];
							}else{
								nm=undefined;
								break;
							}
						}
					}
					i++;
				}
				path=undefined;
				i=undefined;
			}
		}
		if(typeof nm=='function'){
			req.callback=nm;
			nm=undefined;
			if(req.method=='websocket'){
				req.ws_key=req.head['sec-websocket-key'];
				if(typeof req.ws_key!='string'||req.ws_key=='')return req.cancel()
				req.ms='';
				req.user=req.users[req.url];
				req.accept=crypto.createHash('sha1').update(req.ws_key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest("base64");
				req.start=function(uid){
					if(!this.status)return 0;
					if(typeof this.user[uid]!='undefined')
						this.user[uid].cancel();
					this.uid=uid;
					this.user[uid]=this;
					this.mode='update';
					this.headwrite(101,{
						upgrade:'websocket',
						connection:'Upgrade',
						'sec-websocket-accept':this.accept,
					});
					this.log();
				}
				req.stop=function(){
					this.callback(this,'end');
					if(this.user.hasOwnProperty(this.uid))
						delete this.user[this.uid];
				}
				req.sendall=function(mss,all){
					for(x in this.user){
						let i=this.user[x];
						if(i.uid!=this.uid||all)
							i.send(typeof mss=='object'?JSON.stringify(mss):mss);
					}
				}
				req.sendto=function(mss,uid,path){
					if(typeof path=='undefined')path=this.user;
					else if(this.users.hasOwnProperty(path))path=this.users[path];
					else return 0;
					
					if(path.hasOwnProperty(uid)){
						path[uid].send(typeof mss=='object'?JSON.stringify(mss):mss);
						return 1;
					}
					
					return 0;
				}
				req.send=function(data,code){
					this.sendwrite(data,code)
				};
				req.json=function(a){
					this.send(JSON.stringify(a));
				}
				req.on('end',()=>{
					req.stop()
				});
				req.on('error',()=>{
					req.stop()
				});
				req.callback(req,'start');
			}else{
				req.q=function(a,b){
					let i=this.body;
					if(i.hasOwnProperty(a)){
						i=i[a];
						if(typeof i=='object')
							return i.hasOwnProperty(b)?i[b]:i[i.length-1];
						else return i;
					}else return undefined;
				};
				req.check=function(id){
					for(x of id.split(','))
						if(!this.body.hasOwnProperty(x))return 0;
					return 1;
				};
				req.send=function(data,encode){
					this.sendend(data,encode);
				}
				req.location=function(url,code){
					if(typeof code=='undefined')code=301;
					this.headwrite(code,{
						location:url
					});
					this.send('<a href="'+url+'">'+url+'</a>');
				}
				req.json=function(a){
					this.shead('content-type','application/json; charset=UTF-8');
					this.send(JSON.stringify(a));
				}
				req.file=function(file,op){
					if(!this.status)return 0;
					let head={},check;
					if(typeof op!='object')op={};
					if(typeof op.dir!='string')return req.error();
					if(typeof op.type=='string')
						head['content-type']=op.type;
					if(op.load){
						var name=file.split('/');
						head['content-disposition']='attachment; filename="'+name[name.length-1]+'"';
					}
					file=op.dir+file;
					
					try{check=fs.statSync(file)}catch(err){return req.error()}
					
					let range=req.head.range,total=check.size,status=200,io={};
					if(typeof range!='undefined'){
						status=206;
						let parts=range.replace(/bytes=/,"").split("-"),
						start=parseInt(parts[0],10),
						end=parts[1]?parseInt(parts[1],10):total-1;
						this.senddata=(end-start)+1;
						head['content-length']=this.senddata;
						head['accept-ranges']='bytes';
						head['content-range']='bytes '+start+'-'+end+'/'+total;
						io={start:start,end:end};
					}else{
						head['content-length']=total;
						this.senddata=total;
						io={start:0,end:total};
					}
					
					this.headwrite(status,head);
					this.reader=fs.createReadStream(file,io);
					this.reader.pipe(this);
					this.reader.xclose=()=>{
						if(!this.reader||req.reader.cc==1) return;
						this.reader.unpipe(this);
						if(this.reader.close)this.reader.close();
						if(this.reader.destroy)this.reader.destroy();
						this.reader.cc=1;
					};
					
					this.log();
					this.reader.on('error',()=>{
						if(this.reader.cc!=1)this.reader.xclose();
					}).on("end",()=>{
						if(this.reader.cc!=1)this.reader.xclose();
					});
				};
				if(req.head.hasOwnProperty('content-length')){
					let type=req.head['content-type'],
					data=req.raw.slice(req.raw.indexOf('\r\n\r\n')+4);
					if(typeof type=='string'){
						req.size=data.length;
						if(type.search('/x-www-form-urlencoded')>0){
							req.body=req.wwwform(data);
						}else if(type.search('/form-data')>0){
							req.body=req.formdata(data,type.split('multipart/form-data; boundary=')[1]);
						}else if(type.search('/json')>0){
							try{req.body=JSON.parse(data.toString('utf8'))}catch(e){req.body={}}
						}else{
							return req.error(415);
						}
					}
				}
				req.callback(req);
			}
			return 1;
		}
		return req.error();
	}
	#use(method,url,cell){
		if(this.#method[method]){
			let nm=this.#path,bin,i=1;
			if(url.search(/\:|\*/)==-1){
				if(method=='websocket')
					this.#add.users[url]={};
				bin=['!'+method,url];
			}else{
				if(method=='websocket')
					return console.log('websocket not suport url [:|*]');
				bin=('!'+method+url).split('/');
			}
			for(let x of bin){
				if(x.search(/\:/)==0){
					nm.__key=x.substr(1);
					x=':';
				}
				if(typeof nm[x]=='undefined'){
					if(i==bin.length)nm[x]=cell;
					else nm[x]={};
				}
				nm=nm[x];
				i++
			}
		}
		return this;
	}
	all(url,cell){
		for(let x in this.#method)
			if(this.#method[x]&&x!='websocket')
				this.#use(x,url,cell);
		return this;
	}
	pget(url,cell){
		this.#use('get',url,cell);
		this.#use('post',url,cell);
		return this;
	}
	get(url,cell){
		this.#use('get',url,cell);
		return this;
	}
	post(url,cell){
		this.#use('post',url,cell);
		return this;
	}
	options(url,cell){
		this.#use('options',url,cell);
		return this;
	}
	websocket(url,cell){
		this.#use('websocket',url,cell);
		return this;
	}
	constructor(option){
		let config={};
		
		if(this.#is(option.add)){
			for(let x in option.add){
				if(typeof this.#add[x]=='undefined')
					this.#add[x]=option.add[x];
				else console.log('Not add "'+x+'".');
			}
		}
		
		if(this.#is(option.setting)){
			for(let x in option.setting){
				let y=option.setting[x];
				if(x=='url')this.#maxurl=y
				else if(x=='path')this.#maxpath=y
				else if(x=='data')this.#maxdata=y
				else if(x=='socket')this.#maxsocket=y
				else if(x=='timeout')this.#timeout=y
				else if(x=='referer')this.#referer=y
				else if(x=='domain')this.#domain=y
				else if(x=='key')config.key=y
				else if(x=='cert')config.cert=y
			}
		}
			
		if(this.#is(option.method))
			for(let x in option.method)
				this.#method[x]=option.method[x];
		
		if(!this.#is(option.use))
			return console.log('not config option.use');
		else if(option.use!='net'&&option.use!='tls')
			return console.log('please config option.use [net|tls]');
		
		let port=this.#has(option.port,'number',process.env.PORT||(option.use=='tls'?443:80)),
		host=this.#has(option.host,'string',process.env.HOST||'0.0.0.0');
		
		require(option.use).createServer(config,(req)=>{
			req.setTimeout(this.#timeout);
			
			req.time=(new Date()).getTime();
			req.outtime=req.time+this.#timeout;
			req.raw=Buffer.alloc(0);
			req.sendhead={};
			req.body={};
			req.key={};
			req.head=[];
			req._data=[];

			for(let x in this.#add)req[x]=this.#add[x];

			req.on('data',(db)=>{
				req._length+=db.length;
				if(req._block){
					if(typeof req.stop=='function')req.stop();
					return req.destroy();
				}else if(req._length>this.#maxdata||req._lenall>this.#maxdata){
					req._block=1;
					return req.error(411);
				}else if(req.mode=='update'){
					req.ws_len=db[1]&0x7F;
					req.ws_key='';
					req.ws_index=2;
					req.ms=Buffer.alloc(0);
					
					if((db[1]&0x80)==0x80){
						if(db[0]==136)return req.cancel();
						if(req.ws_len==126){
							req.ws_len=db.readUInt16BE(2);
							req.ws_index+=2;
						}else if(req.ws_len==127){
							if(db.readUInt32BE(2)!=0)req.ws_index+=9999;
							req.ws_len=db.readUInt32BE(6);
							req.ws_index+=8;
						}
						
						if(db.length>=req.ws_index+4+req.ws_len){
							req.ws_key=db.slice(req.ws_index,req.ws_index+4);
							req.ws_index+=4;
							req.ms=db.slice(req.ws_index,req.ws_index+req.ws_len);
							for(let i=0;i<req.ms.length;i++)
								req.ms[i]=req.ms[i]^req.ws_key[i%4];
						}
						req.callback(req,'data');
					}else{
						return req.cancel();
					}
				}else{
					req._data.push(db);
					if(req._check){
						req._rawhead+=db.toString('utf8');
						req._len=req._rawhead.search('\r\n\r\n');
						req._rdb=req._rawhead.substring(0,req._rawhead.search('\r\n')).split(' ');
						if(req._rdb.length==3){
							if(req._rdb[1].length>this.#maxurl)return req.error(400);
							req.method=req._rdb[0].toLowerCase();
							req.http=req._rdb[2];
							req._ipath=req._rdb[1].search(/\?/);
							if(req._ipath==-1){
								req.url=req._rdb[1];
								req.queue={}; 
							}else{
								req.url=req._rdb[1].substring(0,req._ipath);
								req.queue=req.wwwform(req._rdb[1].substr(req._ipath+1));
							}
						}else return req.error(400);
						if(req._len!=-1){
							req._check=0;
							req._xhead=req._rawhead.substring(0,req._len);
							req._xhead.split('\r\n').slice(1).forEach((x,i)=>{
								i=x.search(':');
								if(i!=-1)
									req.head[x.substring(0,i).toLowerCase()]=decodeURIComponent(x.substr(i+1).trim());
							})
							
							req.isRef=0;
							if(req.head.hasOwnProperty('referer')){
								if(this.#referer.indexOf(req.head.referer.substr(req.head.referer.search('://')+3).split('/')[0])!=-1)req.isRef=1;
							}
							
							if(this.#domain.indexOf(req.head.hasOwnProperty('host')?req.head.host:'')==-1)
								return req.cancel();
              
							if(req.method=='get'&&req.head.hasOwnProperty('content-length'))
								return req.error(400);
							
							if(req.head.upgrade=='websocket'){
								req.method='websocket';
								if(req.head['sec-websocket-version']!=13)
									return req.cancel();
								req._cuser=0;
								for(let x in req.users)
									for(let y in req.users[x])
										req._cuser++;
								if(req._cuser>=this.#maxsocket)
									return req.cancel();
							}
							
							if(req.head.hasOwnProperty('content-length')){
								req._lenall=parseInt(req.head['content-length'],0)+req._xhead.length+4;
								if(req._length==req._lenall){
									req.raw=Buffer.concat(req._data);
									if(req.method!='websocket')req._block=1;
									this.#callback(req);
								}
							}else{
								if(req.method!='websocket')req._block=1;
								this.#callback(req);
							}
						}
					}else if(req._length==req._lenall){
						req.raw=Buffer.concat(req._data);
						if(req.method!='websocket')req._block=1;
						this.#callback(req);
					}
				}
			}).on('timeout',()=>{
				if(req.head.upgrade!='websocket'&&req.reader==undefined)
					req.error(504);
			}).on('error',(err)=>{
				req.error(502);
			}).on('close',()=>{
				req.status=0;
				req.destroy();
			})
		}).listen(port,host,(a)=>{
			console.clear();
			console.log('');
			console.log('\t\x1b[32m      RRRRRRR \x1b[36m  9999999  333333  88888888  ');
			console.log('\t\x1b[32m     RR   RR \x1b[36m  99   99      33  88    88  ');
			console.log('\t\x1b[32m    RR   RR \x1b[36m  99   99      33  88    88  ');
			console.log('\t\x1b[32m   RRRRRRR \x1b[36m  9999999  333333  88888888  ');
			console.log('\t\x1b[32m  RR  RR  \x1b[36m       99      33  88    88  ');
			console.log('\t\x1b[32m RR   RR \x1b[36m       99      33  88    88  ');
			console.log('\t\x1b[32mRR    RR\x1b[36m  9999999  333333  88888888  \x1b[0m');
			console.log('');
			console.log('\tFrameworks "\x1b[32m'+this.#add.powered+'\x1b[0m"');
			console.log('\t\x1b[33mStart \x1b[37m'+host+':'+port+'\x1b[0m');
			console.log('\n\x1b[43m\x1b[30mMODE   LOAD   OUT    IN     STATUS  USERNAME      URL            \x1b[0m');
			
			process.on('SIGINT',()=>{
				console.clear();
				process.exit();
			});
			process.stdin.on('data', data => {
				var ms=data.toString('utf8').trim();
				if(ms=='clear'){
					console.clear()
				}else if(ms=='exit'){
					process.exit()
				}
			});
		});
	}
};