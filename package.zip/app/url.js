module.exports=function(app,base){
	app.get('/favicon.ico',(req)=>{
		req.fopen('upload/'+base.set('favicon.ico'))
	}).
	get('/robots.txt',(req)=>{
		req.shead('content-type','text/plain; charset=UTF-8');
		req.send(base.set('robots.txt'));
	}).
	get('/sitemap.xml',(req)=>{
		req.shead('content-type','application/xml; charset=UTF-8');
		req.send(base.set('sitemap.xml'));
	}).
	post('/:id/:path',(req)=>{
		if(req.key.id==base.set('admin')&&req.isRef){
			let path=req.key.path;
			req.token=req.usecookie().token;
			req.myid=base.check(req.token);
			if(req.myid==0){
				base.page.login(req,base);
			}else{
				let root=req.myid.type;
				if(path=='dashboard'){
					base.page.dashboard(req,base);
				}else if(path=='mydb'&&root=='admin'){
					base.page.mydb(req,base);
				}else if(path=='file'&&root=='admin'){
					base.page.file(req,base);
				}else if(path=='profile'){
					base.page.profile(req,base);
				}else if(path=='tools'){
					base.page.tools(req,base);
				}else if(path=='logout'){
					base.page.logout(req,base);
				}else req.json({
					status:200,
					root:{type:root,script:'xopen("/'+base.set('admin')+'/dashboard")'}
				});
			}
		}else req.json({status:403});
	}).
	get('/file/css/:file',(req)=>{
		base.page.css(req,base);
	}).
	get('/file/script/:file',(req)=>{
		base.page.script(req,base);
	}).
	get('/file/*',(req)=>{
		var pn=req.key._path;
		if(pn.split('..').length===1){
			if(pn.length>0&&pn[pn.length-1]=='/')pn+='index.html';
			var type=base.mime(pn);
			if(type==false)req.error();
			else req.file(pn,{
				type:type,
				dir:'file/'
			});
		}else req.error();
	}).
	get('/:id/:path',(req)=>{
		if(req.key.id==base.set('admin'))req.fopen('dash/index.html','web/');
		else req.error();
	})
}