let md5=require('../app/md5'),
fs=require('fs'),
r938=require('../app/db');

let mydb={
	user:["user","pass","name","time","type","ip","mail"],
	ref:["id","user","pass","exp","ip","agent"],
	setting:["id","value"],
	token:["id","name"],
	log:["id","token","data","time"],
	message:["id","message"],
}
module.exports.db={
	user:new r938('user',mydb.user),
	ref:new r938('ref',mydb.ref),
	setting:new r938('setting',mydb.setting),
	token:new r938('token',mydb.token),
	log:new r938('log',mydb.log),
	message:new r938('message',mydb.message),
}
module.exports.page={
	login:require("../page/dash/login"),
	logout:require("../page/dash/logout"),
	dashboard:require("../page/dash/dashboard"),
	file:require("../page/dash/file"),
	profile:require("../page/dash/profile"),
	mydb:require("../page/dash/mydb"),
	tools:require("../page/dash/tools"),
	
	script:require("../page/file/script"),
	css:require("../page/file/css"),
}
module.exports.set=function(a){
	let id=this.db.setting.one(a);
	if(id!=0)return id.value;
	return ''
}
module.exports.mydb=mydb;
module.exports.cache={};
module.exports.cref=0;
module.exports.jsons=function(a){
	try{return JSON.parse(a)}catch(e){return {}}
}
module.exports.sweet=function(title,content,icon,fbt1,fbt2){
	let send={
		icon:icon,
		title:title,
		content:content
	};
	if(typeof icon=='undefined')icon='success';
	if(typeof content=='undefined')content='';
	if(typeof title=='undefined')title='';
	if(typeof fbt1=='string')send.fbt1=fbt1;
	if(typeof fbt2=='string')send.fbt2=fbt2;
	
	return send;
}
module.exports.mini=function(a){
	return a.toString().replace(/[\t\n\r]/g,'');
}
module.exports.tennum=function(str){
	if(typeof str=='number')return (str>9?'':'0')+str;
	else return str;
};
module.exports.ims=function(str){
	let t='',m=0,s='';
	for(x of str.split('')){
		if(x=='{'&&m==0)m=1,s='';
		else if(x=='}'&&m==1){
			if(s=='date'){
				let d=new Date();
				t+=this.tennum(d.getDate())+'/'+this.tennum(d.getMonth()+1)+'/'+d.getFullYear()
			}else if(s=='time'){
				let d=new Date();
				t+=this.tennum(d.getHours())+':'+this.tennum(d.getMinutes())+':'+this.tennum(d.getSeconds())
			}
			m=0,s='';
		}else if(m==1)s+=x;
		else t+=x;
	}
	return t
}
module.exports.md5=function(a,n){
	if(typeof n=='number'){
		for(let i=0;i<n;i++)a=md5(a);
	}else a=md5(a);
	
	return a;
}
module.exports.pass=function(a){
	return md5('R938-'+md5(a)+'-password');
}
module.exports.mime=function(a){
	let b=a.split('.'),mime={
		apng:'image/apng',		avif:'image/avif',
		gif:'image/gif',		jpeg:'image/jpeg',
		jpg:'image/jpeg',		png:'image/png',
		svg:'image/svg+xml',	webp:'image/webp',
		ico:'image/x-icon',		rar:'application/vnd.rar',
		zip:'application/zip',	pdf:'application/pdf',
		ogg:'audio/ogg',		mp3:'audio/mpeg',
		mp4:'video/mp4',		webm:'video/webm',
		avi:'video/x-msvideo',	otf:'font/otf',
		woff:'font/woff',		woff2:'font/woff2',
		ttf:'font/ttf',
		xml:'application/xml; charset=UTF-8',		
		json:'application/json; charset=UTF-8',
		js:'text/javascript; charset=UTF-8',		
		css:'text/css; charset=UTF-8',
		html:'text/html; charset=UTF-8',		
		txt:'text/plain; charset=UTF-8'
	};
	b=b[b.length-1].toLowerCase();
	return typeof mime[b]=='string'?mime[b]:0;
}
module.exports.time=function(a){
	if(typeof a!='number')a=0;
	return (((new Date).getTime()*0.001).toFixed(0)*1)+a;
}
module.exports.login=function(user,pass,option){
	if(typeof option!='object')option={};
	let us=this.db.user,token,send={status:1,token:''},
	db=us.one(user);
	if(db!=0){
		pass=this.pass(pass);
		if(db.pass==pass){
			token=this.token({
				exp:this.time(604800),
				user:user,
				pass:pass,
				ip:option.ip,
				agent:option.agent
			});
			if(token!=0)send.token=token;
			else send.status='token';
		}else send.status='pass';
	}else send.status='user';
	return send;
}
module.exports.token=function(a){
	let token=md5(this.time()+JSON.stringify(a));
	let ref=this.db.ref;
	a.id=token;
	if(ref.add(a))return token;
	return 0;
}
module.exports.logout=function(token){
	let ref=this.db.ref;
	return ref.has(token)?ref.remove(token):0;
}
module.exports.check=function(token){
	let ref=this.db.ref;
	let user=this.db.user;
	let id=ref.one(token);
	if(id!=0){
		let u=user.one(id.user);
		if(u!=0&&u.pass==id.pass&&(id.exp*1)-this.time()>0){
			if(id.exp*1-this.time()<604740)
				ref.set(token,{exp:this.time(604800)});
			if(this.cref-this.time()<=0){
				this.cref=this.time(600)
				this.reref()
			}
			return u;
		}else{
			ref.remove(token);
		}
	}
	return 0;
}
module.exports.reref=function(){
	let ref=this.db.ref,
	all=ref.show(),
	rm=[];
	for(let x in all)
		if((all[x].exp*1)-this.time()<=0)
			rm.push(x);
		
	if(rm.length>0)ref.removes(rm)
}
module.exports.escapeHtml=function(a){
if(typeof a=="string")return a.replace(/[<>]/g,function(m){return {
'<':'&lt;',
'>':'&gt;',
}[m]})
}
module.exports.ranstr=function(len){
	var r='',srt='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	for(var i=0;i<len;i++)
		r+=srt.charAt(Math.floor(Math.random()*srt.length));
	return r;
}
module.exports.fopen=function(file,dir){
	this.file(file,{type:this.mime(file),dir:typeof dir=='string'?dir:'file/'});
}
module.exports.upload=function(name,file,ch,path){
	if(!ch)name=name.replace(/[\@\[\]\/\{\}\(\)\*\+\?\#\\\^\$\|\%\!\&\=\+\s]/g,'');
	let op=name.split('.'),xname='file/upload/';
	if(typeof path=='string')xname=path;
	if(op.length>1){
		let type=op[op.length-1].toLowerCase(),code='';
		if(type=='txt'||type=='html'||type=='json'||type=='js'||type=='css')
			code='utf8';
		else if(type=='png'||type=='jpg'||type=='jpeg'||type=='ico'||type=='gif'||type=='webp')
			code='ascii';
		else return 0;
		if(ch)xname+=op.slice(0,-1).join('');
		else xname+=md5('file_'+(new Date()).getTime());
		xname+='.'+type;
		if(xname[0]=='.')xname=type+'_'+xname;
		try{
			fs.writeFileSync(xname,file,{encoding:code});
			return xname;
		}catch(e){
			return 0;
		}
	}
	return 0;
}
module.exports.strword=function(str,f,n){
	let a=str.indexOf(f)+f.length,b;
	if(a==-1)return '';
	str=str.substring(a);
	if(n!=undefined){
		b=str.indexOf(n);
		if(b==-1)return '';
		str=str.substring(0,b);
	}
	return (str);
}
module.exports.url=function(op,callback){
	let send='',data=[],st=1;
	if(typeof op=='string')op={url:op};
	if(typeof op.use!='string')op.use='https';
	
	op.headers={};

	if(typeof op.url=='string'){
		let cc=op.url.match(/(.*)\:\/\/([^\/|\?|\#]*)(.*)/);
		if(cc!=null&&cc.length==4){
			op.port=443;
			op.hostname=cc[2];
			op.path=cc[3]==''?'/':cc[3];
		}
	}
	if(typeof op.timeout=='undefined')op.timeout=3000;
	
	if(typeof op.json=='object'){
		send=JSON.stringify(op.json);
		op.headers['content-type']='application/json';
		op.headers['content-length']=send.length;
		op.method='POST';
	}
	if(typeof op.body!='undefined'){
		if(typeof op.body=='object'){
			for(x in op.body)
				send+=(send==''?'':'&')+x+'='+encodeURIComponent(op.body[x]);
		}else if(typeof op.body=='string'){
			send=op.body;
		}
		op.headers['content-type']='application/x-www-form-urlencoded';
		op.headers['content-length']=send.length;
		op.method='POST';
	}
	
	if(typeof op.agent=='string'){
		op.headers['user-agent']=op.agent;
		delete op.agent;
	}else{
		op.headers['user-agent']='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36';
	}
	if(typeof op.ref=='string'){
		op.headers['referer']=op.ref;
	}
	if(typeof op.ck=='string'){
		op.headers['cookie']=op.ck;
	}
	if(typeof op.cookie=='object'){
		let ck='';
		for(x in op.cookie)
			ck+=(ck==''?'':'; ')+x+'='+encodeURIComponent(op.cookie[x]);
		op.headers['cookie']=ck;
	}
	if(typeof op.method=='undefined')op.method='GET';
	if(typeof op.encode=='undefined')op.encode='utf8';
	if(typeof op.head=='object'){
		for(x in op.head)op.headers[x]=op.head[x];
	}
	if(typeof callback!='function')callback=function(){};
	try{
		require(op.use).request(op,(res)=>{
			res.on('data',(chunk)=>{
				data.push(chunk);
			}).on("end",()=>{
				data=Buffer.concat(data);
				if(op.encode!='raw')data=data.toString(op.encode);
				if(st)callback(res.statusCode,data,res.headers);
				res.destroy();
				st=0;
			}).on('error',(err)=>{
				data=Buffer.concat(data);
				if(op.encode!='raw')data=data.toString(op.encode);
				if(st)callback('error',data,{});
				res.destroy();
				st=0;
			}).on('timeout',()=>{
				data=Buffer.concat(data);
				if(op.encode!='raw')data=data.toString(op.encode);
				if(st)callback('timeout',data,{});
				res.destroy();
				st=0;
			})
		}).end(send);
	}catch(e){
		console.log(e);
		data=Buffer.concat(data);
		if(op.encode!='raw')data=data.toString(op.encode);
		callback('error',data,{});
	}
}
module.exports.recap=function(key,call){
	this.url({
		url:'https://www.google.com/recaptcha/api/siteverify',
		body:{
			secret:this.set('capnode'),
			response:key
		}
	},(code,data)=>{
		if(code==200){
			let i=this.jsons(data);
			if(i.hasOwnProperty("success")&&i.success==true){
				return call('ok')
			}
		}
		call('err')
	})
}