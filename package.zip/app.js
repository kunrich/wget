let server=require('./app/server'),
base=require('./app/base'),
fs=require('fs');

let domain='172.16.0.6';

let app=new server({
	use:'net',
	add:{
		mime:base.mime,
		fopen:base.fopen,
		upload:base.upload,
	},
	setting:{
		domain:[domain],
		referer:[domain]
	}
});

app
.get('/',(req)=>{
	req.json({status:200});
})
.post('/api',(req)=>{
	let user=base.db.token.one(req.head.token);
	if(user!=0){
		let cc=404;
		if(req.check('line')){
			let line=req.q('line');
			let ms=base.db.message.one(line);
			if(ms!=0){
				cc=200;
				base.db.log.add({
					id:base.db.log.length+'.'+Math.floor(Math.random()*10),
					token:req.head.token,
					data:'line/'+line,
					time:base.time()
				});
				if(base.set('line_notify')=="1"){
					base.url({
						url:'https://notify-api.line.me/api/notify',
						head:{
							authorization:'Bearer '+base.set('line_token')
						},
						body:{
							message:base.ims(ms.message)
						}
					},(st,db)=>{});
				}
			}else cc=400;
		}
		req.json({status:cc});
	}else req.error(404);
})

require('./app/url')(app,base)