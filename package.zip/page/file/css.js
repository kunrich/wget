module.exports=function(req,base){
	let path=req.key.file,txt='';
	
	if(base.cache.hasOwnProperty(path+'css')){
		txt=base.cache[path+'css']
	}else{
		let load=[],fs=require('fs');
		if(path=='admin'){
			load=[
				'css/font.css',
				'css/form.css',
				'css/button.css',
				'css/icon.css',
				'css/basic.css',
				'css/sweet.css',
				'css/tem.css',
				'dash/style.css',
			]
		}else return req.error();
		
		for(x of load)txt+=fs.readFileSync('web/'+x)
		txt=base.mini(txt)
		//base.cache[path+'css']=txt;
	}
	
	req.shead('content-type','text/css; charset=UTF-8');
	req.send(txt);
}