module.exports=function(req,base){
	let path=req.key.file,txt='';
	
	if(base.cache.hasOwnProperty(path+'js')){
		txt=base.cache[path+'js']
	}else{
		let load=[],js='',fs=require('fs');
		let head='let _name=['+JSON.stringify(base.set('name'))+'][0],_ref=location.host,_logo=['+JSON.stringify(base.set('logo'))+'][0]';
		if(path=='admin'){
			load=[
				'script/tool.js',
				'dash/script.js',
			]
			js=head+',_load={type:""};';
		}else return req.error();
		
		for(x of load)txt+=fs.readFileSync('web/'+x)
		txt=base.mini(js+txt);
		//base.cache[path+'js']=txt;
	}
	
	req.shead('content-type','application/javascript; charset=UTF-8');
	req.send(txt);
}