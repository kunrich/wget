module.exports=function(req,base){
	if(req.check('code,file')){
		let obj={};
		try{
			obj=JSON.parse(req.q('code'));
		}catch(e){}
		
		if(typeof obj=='object'){
			let db=base.db[req.q('file')];
			let no=typeof obj.no=='number'?obj.no:1,
			show=typeof obj.show=='number'?obj.show:24;
			
			let r=db.get(
				typeof obj.search=='object'?obj.search:[],
				typeof obj.by=='string'?obj.by:'',
				typeof obj.sort=='number'?obj.sort:0,
				no,
				show
			);
			req.json({
				status:200,
				type:req.myid.type,
				root:{script:'dash.mydb.load(a)'},
				data:r,
				no:no,
				show:show
			});
		}else req.json({status:400});
	}else if(req.check('file,ids,edit')){
		let obj=JSON.parse(req.q('edit'));
		let key=JSON.parse(req.q('ids'));
		let id=req.q('id');
		if(typeof obj=='object'&&typeof key=='object'){
			let db=base.db[req.q('file')];
			let rs={},s='';
			for(x of key){
				rs[x]=obj;
				s+=(s==''?'':', ')+x;
			}
			let ms=db.sets(rs)?
			'dash.mydb.send.click();toast.success("แก้ไขข้อมูล <b>'+s+'</b> สำเร็จ")':
			'toast.error("แก้ไขข้อมูลเกิดข้อผิดพลาด")';
			req.json({
				status:200,
				type:req.myid.type,
				root:{script:ms}
			});
		}else req.json({status:400});
	}else if(req.check('file,id,edit')){
		let obj=JSON.parse(req.q('edit'));
		let id=req.q('id');
		if(typeof obj=='object'){
			let db=base.db[req.q('file')];
			let ms=db.set(id,obj)?
			'dash.mydb.send.click();toast.success("แก้ไขข้อมูล <b>'+id+'</b> สำเร็จ")':
			'toast.error("แก้ไขข้อมูลเกิดข้อผิดพลาด")';
			req.json({
				status:200,
				type:req.myid.type,
				root:{script:ms}
			});
		}else req.json({status:400});
	}else if(req.check('file,edit')){
		let db=base.db[req.q('file')];
		let r=db.one(req.q('edit'));
		let ms=r!=0?
		'dash.mydb.edit(a)':
		'toast.error("โหลดหน้าแก้ไขข้อมูลไม่สำเร็จ")';
		req.json({
			status:200,
			type:req.myid.type,
			root:{script:ms},
			data:r!=0?r:{}
		});
	}else if(req.check('file,add')){
		let obj=JSON.parse(req.q('add'));
		if(typeof obj=='object'){
			let db=base.db[req.q('file')];
			let ms=db.add(obj)?
			'dash.mydb.add();toast.success("เพิ่มข้อมูลสำเร็จ")':
			'toast.error("เกิดข้อผิดพลาดไอดีซ้ำ")';
			req.json({
				status:200,
				type:req.myid.type,
				root:{script:ms}
			});
		}else req.json({status:400});
	}else if(req.check('file,copy')){
		let obj=JSON.parse(req.q('copy'));
		if(typeof obj=='object'){
			let db=base.db[req.q('file')];
			let ms=db.add(obj)?
			'dash.mydb.send.click();toast.success("คัดลองข้อมูลสำเร็จ")':
			'toast.error("เกิดข้อผิดพลาดไอดีซ้ำ")';
			req.json({
				status:200,
				type:req.myid.type,
				root:{script:ms}
			});
		}else req.json({status:400});
	}else if(req.check('file,remove')){
		let db=base.db[req.q('file')];
		let ms=db.remove(req.q('remove'))?
		'dash.mydb.send.click();toast.success("ลบข้อมูล <b>'+req.q('remove')+'</b> สำเร็จ")':
		'toast.error("ลบข้อมูลเกิดข้อผิดพลาด")';
		req.json({
			status:200,
			type:req.myid.type,
			root:{script:ms}
		});
	}else if(req.check('file,removes')){
		let obj=JSON.parse(req.q('removes'));
		if(typeof obj=='object'){
			let db=base.db[req.q('file')];
			let ms=db.removes(obj)?
			'dash.mydb.send.click();toast.success("ลบข้อมูลสำเร็จ")':
			'toast.error("ลบข้อมูลเกิดข้อผิดพลาด")';
			req.json({
				status:200,
				type:req.myid.type,
				root:{script:ms}
			});
		}else req.json({status:400});
	}else if(req.check('get')){
		let file=req.q('get');
		req.json({
			status:200,
			type:req.myid.type,
			root:{
				script:'dash.mydb.get(a)'
			},
			key:base.mydb[file],
			file:file
		});
	}else{
		let dbs=[];
		for(x in base.mydb){
			dbs[dbs.length]=x;
		}
		req.json({
			status:200,
			type:req.myid.type,
			root:{
				script:'dash.mydb.home(a)'
			},
			dbs:dbs
		});
	}
}