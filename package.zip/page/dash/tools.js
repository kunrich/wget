module.exports=function(req,base){
	if(req.check('pass')){
		if(req.myid.type=='admin'){
			req.json({
				status:200,
				type:req.myid.type,
				pass:base.pass(req.q('pass')),
				root:{
					script:'let id=q("#icode");if(id)id.value=a.pass'
				}
			});
		}else req.json({
			status:200,
			type:req.myid.type,
			toast:'0Only account Admin'
		});
	}else req.json({
		status:200,
		type:req.myid.type,
		root:{
			script:'dash.tools.home(a)'
		}
	});
}