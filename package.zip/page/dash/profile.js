module.exports=function(req,base){
	let us=base.db.user,id=req.myid;
	if(req.check('o,n,r')){
		let txt='0ไม่สามารถแก้ไขรหัสผ่านใหม่ได้';
		
		if(req.q('n')!=req.q('r')){
			txt='0รหัสผ่านไม่ตรงกัน';
		}else if(req.q('n').length<6){
			txt='0รหัสผ่านใหม่สั้นกินไป';
		}else if(req.q('n').length>100){
			txt='0รหัสผ่านใหม่ยาวเกินไป';
		}else if(base.pass(req.q('o'))!=id.pass){
			txt='0รหัสผ่านเก่าไม่ถูกต้อง';
		}else if(us.set(id.user,{
			pass:base.pass(req.q('n'))
		})){
			let ref=base.db.ref;
			ref.set(req.token,{
				pass:base.pass(req.q('n'))
			});
			txt='1เปลี่ยนรหัสผ่านใหม่สำเร็จ';
		}
		req.json({
			status:200,
			type:id.type,
			toast:txt
		});
	}else if(req.check('name')){
		let ic=0,
		txt='ไม่สามารถแก้ไขชื่อได้',
		name=base.escapeHtml(req.q('name').trim());
		
		if(name==''){
			txt='ห้ามเว้นว่าง';
		}else if(name.length>40){
			txt='ชื่อยาวเกินไป';
		}else if(us.set(id.user,{
			name:name
		})){
			ic=1;
			txt='เปลี่ยนชื่อสำเร็จ';
		}
		req.json({
			status:200,
			type:id.type,
			toast:ic+txt
		});
	}else req.json({
		status:200,
		type:id.type,
		user:id.user,
		name:id.name,
		root:{
			script:'dash.profile.home(a)'
		}
	});
}