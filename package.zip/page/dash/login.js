module.exports=function(req,base){
	if(req.check('user,pass')){
		let user=base.db.user;
		let id=base.login(req.q('user'),req.q('pass'),{
			ip:req.ip(),
			agent:req.head['user-agent']
		});
		
		if(id.status==1){
			req.scookie('token',id.token,{
				'Max-Age':60*60*24*7,
				'Path':'/'
			});
			req.json({
				status:200,
				type:'',
				root:{
					script:'xopen("/'+base.set('admin')+'/dashboard")'
				}
			});
		}else{
			let err='The error could not be identified.';
			if(id.status=='user')err='Username incorrect.';
			else if(id.status=='pass')err='password incorrect.';
			else if(id.status=='token')err='Error new Token.';
			req.json({
				status:200,
				type:'',
				sweet:base.sweet('Login',err,'error')
			});
		}
		
	}else req.json({
		status:200,
		type:'',
		root:{
			script:'dash.login.home(a)'
		}
	});
}