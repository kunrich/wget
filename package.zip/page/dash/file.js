let fs=require('fs');
module.exports=function(req,base){
	if(req.check('list,dir')){
		let list={};
		try{
			list=fs.readdirSync('file/'+req.q('dir').replace(/\./g,''));
		}catch(e){}
		req.json({
			status:200,
			type:req.myid.type,
			list:list,
			root:{script:'dash.file.list(a)'}
		});
	}else if(req.check('del,dir')){
		let txt='0เกิดข้อผิดพลาดบางอย่าง';
		try{
			fs.unlinkSync('file/'+req.q('dir').replace(/\./g,'')+req.q('del'));
			txt='1ลบไฟล์สำเร็จ';
		}catch(e){}
		req.json({
			status:200,
			type:req.myid.type,
			toast:txt,
			root:{script:'post({body:{list:1,dir:dash.file.dir.value}})'}
		});
	}else if(req.check('name,file,dir')){
		let file=req.q('file'),dir=req.q('dir').replace(/\./g,''),name=req.q('name'),ext=file.name.split('.');
		ext=ext[ext.length-1];
		let txt='0เกิดข้อผิดพลาดบางอย่าง',s='';
		
		let upload=req.upload((name==''?base.time():name)+'.'+ext,file.data,1,'file/'+dir);
		if(upload==0){
			txt='0ไม่สามารถอัพโหลดไฟล์ได้';
		}else{
			txt='1อัพโหลดโปรไฟล์สำเร็จ';
			s='dash.file.success(a)';
		}
		
		req.json({
			status:200,
			type:req.myid.type,
			toast:txt,
			file:upload,
			root:{script:s}
		});
	}else req.json({
		status:200,
		type:req.myid.type,
		root:{
			script:'dash.file.home()'
		}
	});
}