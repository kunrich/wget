let dash={
mydb:{
	bt:{},
	key:[],
	file:'',
	qcode:{},
	input:{},
	send:{},
	run:function(c){
		var a=jsons(this.qcode.value);
		if(typeof c=="object"){
			for(x in c)a[x]=c[x];
			this.qcode.value=JSON.stringify(a);
		}
		return a;
	},
	home:function(a){
		q("title").html('Database - '+_name);
		let root=q('root').html('').tag('width').tag('card').tag('box');
		root.tag('h1',{atb:{dir:'c'},html:'Database'});
		root.tag('p',{html:'Database List'});
		let idb=root.tag('div',{atb:{dir:'l'}});
		
		for(x in a.dbs){
			var c=a.dbs[x];
			idb.tag('button',{
				html:'<w ic="_f164"></w>'+c[0].toUpperCase()+c.substr(1),
				set:{dbs:c},atb:{
					class:'bt success'
				},css:{
					display:'block',
					minWidth:'150px',
					textAlign:'left'
				}
			}).on('click',function(){
				post({body:{get:this.dbs}})
			});
		}
	},
	get:function(a){
		this.key=a.key;
		this.file=a.file;
		this.tag=a.key[0];
		dash.mydb.bt={};
		let root=q('root').html('').tag('width').tag('card').tag('box');
		root.tag('h1',{atb:{dir:'c'},html:'Database '}).tag('badge',{atb:{class:'success'},html:a.file});
		let mm=root.tag('p',{atb:{dir:'l'}});
		mm.tag('a',{atb:{class:'bt'},html:'<w ic="_f002"></w>Search'}).on('click',function(){
			xsweet({
				job:'input',
				title:'Search',
				tbt1:'OK',
				submit:function(a){
					dash.mydb.run({search:[[dash.mydb.key[0],'=',a]],no:1});
					dash.mydb.send.click();
				}
			})
		});
		mm.tag('a',{atb:{class:'bt'},html:'<w ic="_f075"></w>Show'}).on('click',function(){
			dash.mydb.run({search:[[dash.mydb.key[0],'!','']]});
			dash.mydb.send.click();
		});
		mm.tag('a',{atb:{class:'bt info',toggle:'#tool'},html:'<w ic="_f013"></w>Advanced'});
		
		let av=root.tag('card',{atb:{id:'tool'}}).tag('box',{atb:{dir:'l'}});
		av.tag('p',{html:'Menu'});
		let ms=av.tag('div');
			ms.tag('a',{atb:{class:'bt success'},html:'<w ic="_f061"></w>Add'}).on('click',function(){
				dash.mydb.add()
			});
			ms.tag('a',{atb:{class:'bt'},html:'<w ic="_f03c"></w>Edits'}).on('click',function(){
				var dbs=[],id=dash.mydb.input.qs('input[type=checkbox]');
				id.forEach(function(a){
					if(a.checked)dbs[dbs.length]=a.dbs
				});
				if(dbs.length>0)dash.mydb.edits(dbs)
			});
			ms.tag('a',{atb:{class:'bt danger'},html:'<w ic="_f17f"></w>Removes'}).on('click',function(){
				var dbs=[],id=dash.mydb.input.qs('input[type=checkbox]');
				id.forEach(function(a){
					if(a.checked)dbs[dbs.length]=a.dbs
				});
				if(dbs.length>0)xsweet({
					dbx:dbs,
					job:'confirm',
					submit:function(sw){
						post({body:{
							file:dash.mydb.file,
							removes:JSON.stringify(sw.data.dbx)
						}})
					}
				})
			});
		av.tag('p',{html:'Select tag show'});
		let tag=av.tag('select').on('change',function(){
			dash.mydb.tag=this.value
		});;
		av.tag('p',{html:'Command'});
		this.qcode=av.tag('textarea',{css:{fontSize:'18px'}});
		this.send=av.tag('div').tag('a',{atb:{class:'bt'},html:'<w ic="_f047"></w>Run'}).on('click',function(){
			post({body:{
				code:dash.mydb.qcode.value,
				file:dash.mydb.file
			}});
		});
		this.input=q('root width').tag('card').tag('box').tag('auto');
		
		for(x in this.key){
			var i=this.key[x];
			tag.tag('option',{atb:{value:i},html:i})
		}
		this.run({
			by:a.key[0],
			sort:0,
			no:1,
			show:24
		});
	},
	edits:function(i){
		let inp=this.input.html('');
		inp.tag('h1',{atb:{dir:'c'},html:'Edits Database'});
		let list=inp.tag('div');
		for(x in dash.mydb.key){
			var id=dash.mydb.key[x];
			if(x!=0){
				list.tag('p',{html:id});
				list.tag('textarea',{atb:{key:id}})
			}
		}
		inp.tag('hr');
		inp.tag('p',{html:'List ID Edits'});
		let ids=inp.tag('textarea',{set:{value:JSON.stringify(i)}});
		inp.tag('p').tag('button',{set:{
			ids:ids,
			list:list
		},atb:{class:'bt success'},html:'<w ic="_f03c"></w>Edit'}).on('click',function(){
			var a={};
			this.list.qs('textarea').forEach(function(id){
				if(id.value=='[null]')a[id.gatb('key')]='';
				else if(id.value!='')a[id.gatb('key')]=id.value;
			});
			post({
				body:{
					file:dash.mydb.file,
					ids:this.ids.value,
					edit:JSON.stringify(a)
				}
			});
		});
	},
	edit:function(i){
		var b=i.data,id=b[dash.mydb.key[0]];
		let inp=this.input.html('');
		inp.tag('h1',{atb:{dir:'c'},html:'Edit Database '+id});
		let toggle=inp.tag('p');
		let edit=inp.tag('div');
		let open=[];
		for(x in b){
			let p=x;
			let io=toggle.tag('a',{set:{tog:p},atb:{toggle:'#toggle_'+p,class:'bt'},html:p}).on('click',function(){
				var a=this.toggle,b=this.tog;
				if(a.style.height=="0px"){
					this.satb("class","bt success");
					dash.mydb.bt[b]=1
				}else{
					this.satb("class","bt");
					dash.mydb.bt[b]=0
				}
			});
			if(dash.mydb.bt[p]==1)open.push(io);

			let pbox=edit.tag('div',{atb:{id:'toggle_'+p,class:'none toggle'}});
			pbox.tag('p',{html:'<w ic="_f047"></w>'+p});
			pbox.tag('p').tag('textarea',{set:{key:p,value:b[p],oldvalue:b[p]}});
		}
		toggle.tag('button',{
			atb:{class:'bt warning'},html:'<i ic="_f071"></i>',set:{pop:1,toggle:toggle}
		}).on('click',function(){
			var pop=this.pop;
			this.toggle.qs("a").forEach(function(a){
				if(pop){
					if(a.gatb('class')=="bt")a.click();
				}else{
					if(a.gatb('class')!="bt")a.click();
				}
			});
			this.html('<i ic="'+(pop?'_f070':'_f071')+'"></i>');
			this.pop=pop?0:1
		});
		
		let mm=inp.tag('p');
		mm.tag('a',{set:{dbs:id,edit:edit},atb:{class:'bt success'},html:'<w ic="_f0af"></w>Save'}).on('click',function(){
			var a={},i=0;
			this.edit.qs('textarea').forEach(function(id){
				if(id.value!=id.oldvalue){
					a[id.key]=id.value;
					i++
				}
			});
			if(i>0)post({body:{
				file:dash.mydb.file,
				id:this.dbs,
				edit:JSON.stringify(a)
			}});
			else toast.error("No data edit")
		});
		mm.tag('a',{set:{edit:edit},atb:{class:'bt info'},html:'<w ic="_f0ad"></w>Save As'}).on('click',function(){
			xsweet({
				edit:this.edit,
				job:'input',
				title:'Save As ID',
				tbt1:'Save As',
				submit:function(a,sw){
					if(a!=''){
						var db={};
						sw.data.edit.qs('textarea').forEach(function(id){
							db[id.key]=id.value
						});
						db[dash.mydb.key[0]]=a;
						dash.mydb.run({search:[[dash.mydb.key[0],"=",a]],no:1});
						post({body:{
							file:dash.mydb.file,
							copy:JSON.stringify(db)
						}})
					}else toast.error('ID ห้ามเว้นว่าง')
				}
			})
		});
		mm.tag('a',{set:{dbs:id},atb:{class:'bt danger'},html:'<w ic="_f17f"></w>Remove'}).on('click',function(){
			xsweet({
				dbx:this.dbs,
				job:'confirm',
				submit:function(sw){
					post({body:{
						file:dash.mydb.file,
						remove:sw.data.dbx
					}})
				}
			})
		});
		mm.tag('a',{atb:{class:'bt'},html:'Cancel'}).on('click',function(){
			dash.mydb.send.click()
		});
		setTimeout(function(open){
			open.forEach(function(a){a.click()})
		},1,open)
	},
	add:function(){
		let inp=this.input.html('');
		inp.tag('h1',{atb:{dir:'c'},html:'Add Database'});
		let add=inp.tag('div');
		for(x in dash.mydb.key){
			var id=dash.mydb.key[x];
			add.tag('p',{html:id});
			add.tag('textarea',{set:{key:id}});
		}
		inp.tag('p').tag('a',{set:{add:add},atb:{class:'bt success'},html:'<w ic="_f061"></w>Add'}).on('click',function(){
			var a={};
			this.add.qs('textarea').forEach(function(id){
				a[id.key]=id.value;
			});
			post({body:{
				file:dash.mydb.file,
				add:JSON.stringify(a)
			}});
		})
	},
	load:function(a){
		var b=a.data;
		let inp=this.input.html('');
		inp.tag('p',{html:'Databases: '+b.length});
		let xpage=inp.tag('p');
		let pag=inp.tag('div',{atb:{dir:'l'}}).tag('div',{atb:{class:'pagination'}});
		let cc=inp.tag('table',{atb:{dir:'l'},css:{minWidth:'400px'}});
		let head=cc.tag('tr');
		head.tag('th',{html:dash.mydb.tag});
		let op=head.tag('th',{css:{width:'200px'},atb:{dir:'r'}}).tag('select',{css:{padding:'4px 10px',maxWidth:'200px'}}).on('change',function(){
			var v=this.value,
			id=this.tabledb.qs('input[type=checkbox]');
			if(v==1){
				id.forEach(function(a){
					a.checked=1
				})
			}else if(v==2){
				id.forEach(function(a){
					a.checked=0
				})
			}else if(v==3){
				id.forEach(function(a){
					a.checked=a.checked==1?0:1
				})
			}else if(v==4){
				var i=1;
				id.forEach(function(a){
					a.checked=i%2==0;i++
				})
			}else if(v==5){
				var i=1;
				id.forEach(function(a){
					a.checked=i%2!=0;i++
				})
			}
		});
		let xdb=cc.tag('tbody');
		op.tabledb=xdb;
		
		['Not selected','Select all','Not select all','Switch','Double order','Odd order',].forEach(function(id,no){
			op.tag('option',{atb:{value:no},html:id})
		});

		for(x in b.db){
			var c=b.db[x],t=xdb.tag('tr'),i=c[dash.mydb.key[0]];
			
			t.tag('td',{html:c[dash.mydb.tag]});
			let mm=t.tag('td',{atb:{dir:'r'}});
			
			mm.tag('input',{
				atb:{type:'checkbox'},
				set:{dbs:i,op:op}
			}).on('click',function(){
				this.op.value=0
			});
			mm.tag('a',{
				atb:{class:'bt success'},
				set:{dbs:i},
				html:'<i ic="_f03c"></i>'
			}).on('click',function(){
				post({body:{
					file:dash.mydb.file,
					edit:this.dbs
				}});
			});
			mm.tag('a',{
				atb:{class:'bt danger'},
				set:{dbs:i},
				html:'<i ic="_f17f"></i>'
			}).on('click',function(){
				xsweet({
					dbx:this.dbs,
					job:'confirm',
					submit:function(sw){
						post({body:{
							file:dash.mydb.file,
							remove:sw.data.dbx
						}});
					}
				})
			});
		}
		
		var ics=dash.mydb.run();
		ics.show=a.show;
		ics.no=a.no;
		if(typeof ics.show=="number"&&typeof a.no=="number"&&b.length>ics.show){
			var all=Math.ceil(b.length/ics.show);
			var pa=pagination(a.no,all,'','');
			xpage.html('Page: '+a.no+"/"+all);
			pag.html(pa);
			pag.qs('a').forEach(function(a){
				a.no=a.gatb('href')*1;
				a.ratb('href');
				a.ratb('method');
				if(a.innerHTML!='...')a.on('click',function(){
					var a=dash.mydb.run();
					a.no=this.no;
					dash.mydb.run(a);
					dash.mydb.send.click();
				});
			});
		}else xpage.html('Page: 1/1');
	}
},
dashboard:{
	url:'',
	home:function(a){
		q("title").html('Dashboard - '+_name);
		this.url=a.url;
		let root1=q('root').html('').tag('width').tag('card').tag('box').tag('auto');
		let time=root1.tag('div',{atb:{dir:'c',class:'timeclock'},css:{
			fontSize:'80px',
			marginTop:'36px'
		}});
		let tloop={dot:[]};
		tloop.h=time.tag('span',{atb:{class:'th'}});
		tloop.dot.push(time.tag('span',{atb:{class:'dot'},html:'.'}));
		tloop.m=time.tag('span',{atb:{class:'tm'}});
		time.tag('span',{atb:{class:'dot'},html:' '});
		tloop.s=time.tag('span',{atb:{class:'ts'}});
		tloop.d=root1.tag('div',{atb:{dir:'c'},css:{fontSize:'20px',marginBottom:'36px'}});
		itime(tloop);

		let dash=q('root width').tag('card').tag('div',{atb:{class:'dash'}});
		[
			['bbb','_f0a8',a.user,'Users'],
			['bbo','_f18c',a.token,'Token'],
			['bbg','_f170',a.log,'Logger'],
			['bbv','_f07c',a.ref,'Sesion'],
		].forEach(function(x){
			let b=dash.tag('div',{atb:{class:'co '+x[0]}});
			b.tag('i',{atb:{ic:x[1]}});
			b.tag('span',{html:number_format(x[2])});
			b.tag('h3',{html:x[3]});
		});
	}
},
profile:{
	home:function(a){
		q("title").html('Profile - '+_name);
		let root=q('root').html('').tag('width').tag('card').tag('box',{atb:{dir:'c'}});
		root.tag('h1',{atb:{dir:'c'},html:'Profile'});
		let pro=root.tag('div',{atb:{class:'iprofile'}});
		pro.tag('p',{html:'Username'});
		pro.tag('p').tag('input',{atb:{type:'text',value:a.user,disabled:''}});
		pro.tag('p',{html:'Account Type'});
		pro.tag('p').tag('input',{atb:{type:'text',value:a.type,disabled:''}});
		
		pro.tag('br');
		
		pro.tag('p',{html:'Name'});
		let iam=pro.tag('input',{atb:{type:'text',placeholder:'Name',value:a.name}});
		pro.tag('p').tag('button',{set:{
			iam:iam
		},atb:{class:'bt info'},html:'<w ic="_f00c"></w>Change'}).on('click',function(){
			var n=this.iam.value.trim();
			if(n!=''){
				post({
					url:"profile",
					body:{
						name:n
					}
				});
				
			}else toast.error('ชื่อห้ามเว้นว่าง');
		});

		pro.tag('br');

		pro.tag('p',{html:'Change Password'});
		let pass={
			o:pro.tag('p').tag('input',{atb:{type:'password',placeholder:'Old Password'}}),
			n:pro.tag('p').tag('input',{atb:{type:'password',placeholder:'New Password'}}),
			r:pro.tag('p').tag('input',{atb:{type:'password',placeholder:'New Password Again'}})
		};
		pro.tag('p').tag('button',{set:pass,atb:{class:'bt success'},html:'<w ic="_f0af"></w>Save'}).on('click',function(){
			post({
				url:"profile",
				body:{
					o:this.o.value,
					n:this.n.value,
					r:this.r.value
				}
			});
			this.o.value='';
			this.n.value='';
			this.r.value='';
		});
	}
},
login:{
	home:function(){
		q("title").html('Login - '+_name);
		let root=q('root').html('').tag('width').tag('card').tag('box',{atb:{dir:'c'}}).tag('div',{atb:{dir:'l'},css:{display:'inline-block',margin:'40px 0px',width:'100%',maxWidth:'240px'}});
		root.tag('h1',{atb:{dir:'c'},html:'LOGIN'});
		root.tag('label',{css:{margin:'10px 0 0'},html:'<w ic="_f007"></w>Username'});
		let user=root.tag('label',{atb:{class:'flex'}}).tag('input',{atb:{type:"text",placeholder:"Username"}});
		root.tag('label',{css:{margin:'10px 0 0'},html:'<w ic="_f07c"></w>Password'});
		let pass=root.tag('label',{atb:{class:'flex'}}).tag('input',{atb:{type:"password",placeholder:"Password"}});
		let login=root.tag('p',{atb:{dir:'c'}}).tag('button',{atb:{class:"bt"},html:'<w ic="_f16e"></w>Login'});


		login.on("click",function(){
			post({body:{
				user:this.user.value,
				pass:this.pass.value
			}});
		}).user=user;
		login.pass=pass;
		
		user.on("keyup",function(e){
			if(e.key=="Enter"){
				if(this.value==''){
					toast.error('กรุณากรอกชื่อผู้ใช้');
				}else if(this.pass.value==''){
					this.pass.focus()
				}else this.login.click();
			}
		}).pass=pass;
		user.login=login;
		
		pass.on("keyup",function(e){
			if(e.key=="Enter"){
				if(this.value==''){
					toast.error('กรุณากรอกรหัสผ่าน');
				}else if(this.user.value==''){
					this.user.focus()
				}else this.login.click();
			}
		}).user=user;
		pass.login=login;
	}
},
tools:{
	home:function(){
		q("title").html('Tools - '+_name);
		let root=q('root').html('').tag('width').tag('card').tag('box');
		root.tag('h1',{atb:{dir:'c'},html:'Tools'});
		let cmenu=root.tag('p');
		root.tag('textarea',{atb:{id:'icode'}});
		root.tag('div',{atb:{id:'imenu'}});
		[
			['Base64','base64'],
			['URI Component','url'],
			['MD5','md5'],
			['Password','pass'],
			['String','string'],
			['Time','time'],
			['Script','script'],
		].forEach(function(a){
			cmenu.tag('button',{
				html:a[0],
				set:{
					menu:a[1]
				},
				atb:{
					class:'bt info'
				}
			}).on('click',function(){
				let id=this;
				cmenu.qs('button').forEach(function(a){
					a.satb('class','bt '+(a==id?'success':'info'))
				});
				dash.tools[id.menu](id.innerHTML);
			});
		});
	},
	base64:function(a){
		let im=q('#imenu').html(''),val=q('#icode');
		im.html('');
		im.tag('button',{atb:{class:'bt danger'},html:'<w ic="_f013"></w>Encode'}).on('click',function(){
			this.is.value=base64.encode(this.is.value)
		}).is=val;
		im.tag('button',{atb:{class:'bt'},html:'<w ic="_f047"></w>Decode'}).on('click',function(){
			this.is.value=base64.decode(this.is.value)
		}).is=val;
	},
	url:function(a){
		let im=q('#imenu').html(''),val=q('#icode');
		im.tag('button',{atb:{class:'bt danger'},html:'<w ic="_f013"></w>Encode'}).on('click',function(){
			this.is.value=encodeURIComponent(this.is.value)
		}).is=val;
		im.tag('button',{atb:{class:'bt'},html:'<w ic="_f047"></w>Decode'}).on('click',function(){
			this.is.value=decodeURIComponent(this.is.value)
		}).is=val;
	},
	md5:function(a){
		let im=q('#imenu').html('');
		im.tag('button',{atb:{class:'bt danger'},html:'<w ic="_f013"></w>Encode'}).on('click',function(){
			this.is.value=md5(this.is.value)
		}).is=q('#icode');
	},
	pass:function(a){
		let im=q('#imenu').html('');
		im.tag('button',{atb:{class:'bt danger'},html:'<w ic="_f07c"></w>Create'}).on('click',function(){
			post({body:{
				pass:this.is.value
			}})
		}).is=q('#icode');
	},
	string:function(a){
		let im=q('#imenu').html(''),val=q('#icode');
		im.tag('button',{atb:{class:'bt'},html:'<w ic="_f002"></w>Count'}).on('click',function(){
			xsweet({
				title:'Length String',
				content:this.is.value.length
			})
		}).is=val;
		im.tag('button',{atb:{class:'bt'},html:'<w ic="_f03c"></w>Trim'}).on('click',function(){
			this.is.value=this.is.value.trim();
		}).is=val;
		im.tag('button',{atb:{class:'bt'},html:'<w ic="_f071"></w>LowerCase'}).on('click',function(){
			this.is.value=this.is.value.toLowerCase();
		}).is=val;
		im.tag('button',{atb:{class:'bt'},html:'<w ic="_f070"></w>UpperCase'}).on('click',function(){
			this.is.value=this.is.value.toUpperCase();
		}).is=val;
		im.tag('button',{atb:{class:'bt success'},html:'<w ic="_f170"></w>Reverse'}).on('click',function(){
			this.is.value=this.is.value.split('').reverse().join('');
		}).is=val;
		
	},
	time:function(a){
		let im=q('#imenu').html('');
		let ic='<w ic="_f170"></w>',val=q('#icode');
		im.tag('button',{atb:{class:'bt'},html:ic+'Get String'}).on('click',function(){
			this.is.value=(new Date);
		}).is=val;
		im.tag('button',{atb:{class:'bt'},html:ic+'Get (s)'}).on('click',function(){
			this.is.value=((new Date).getTime()*0.001).toFixed(0);
		}).is=val;
		im.tag('button',{atb:{class:'bt'},html:ic+'Get (ms)'}).on('click',function(){
			this.is.value=(new Date).getTime();
		}).is=val;
		im.tag('br');
		im.tag('button',{atb:{class:'bt danger'},html:ic+'Num To Str'}).on('click',function(){
			let a=this.is;
			while(a.value.length<13)a.value+=0;
			a.value=new Date(a.value*1);
		}).is=val;
		im.tag('button',{atb:{class:'bt danger'},html:ic+'Str To Num'}).on('click',function(){
			this.is.value=new Date(this.is.value).getTime();
		}).is=val;
		im.tag('hr');
		im.tag('div',{html:'** String To Number format <b>m/d/y h:m:s</b>'});
	},
	script:function(a){
		let im=q('#imenu').html(''),val=q('#icode');
		im.tag('button',{set:{
			out:im.tag('textarea',{atb:{placeholder:'Output Script...'}}),
			br:im.tag('br')
		},atb:{class:'bt'},html:'<w ic="_f0f1"></w>Script'}).on('click',function(){
			try{
				this.out.value=eval(this.is.value)
			}catch(e){
				this.out.value=e
			}
		}).is=val;
		im.tag('button',{atb:{class:'bt'},html:'<w ic="_f03c"></w>font'}).on('click',function(){
			let css=base64.decode(getCookie('style'));
			if(css=='')css='textarea{\n\tfont-size: 20px;\n\tfont-family: Arial,sans-serif;\n}';
			this.is.value='setstyle(`'+css+'`)'
		}).is=val;
		
	}
},
file:{
	home:function(){
		q("title").html('File Manager - '+_name);
		let root=q('root').html('').tag('width').tag('card').tag('box');
		root.tag('h1',{atb:{dir:'c'},html:'File Manager'});
		root.tag('p',{atb:{dir:'c'},html:'เครื่องมือจัดการไฟล์'});
		this.dir=root.tag('div',{atb:{dir:'c'}}).tag('input',{atb:{placeholder:'Path Dir',value:''}});
		let bt=root.tag('div',{atb:{dir:'c'}});
		bt.tag('button',{atb:{class:'bt'},html:'<w ic="_f074"></w>แสดงไฟล์'}).on('click',function(){
			post({body:{
				list:1,
				dir:dash.file.dir.value
			}});
		});
		bt.tag('button',{atb:{class:'bt success'},html:'<w ic="_f08a"></w>อัพโหลด'}).on('click',function(){
			dash.file.upload()
		});
		this.page=root.tag('div',{css:{marginTop:'30px'}});
	},
	list:function(a){
		let p=this.page.html('').tag('table');
		for(x in a.list){
			let i=a.list[x];
			let r=p.tag('tr');
			let ext=i.split('.');
			ext=ext[ext.length-1];
			if(ext==i)ext='';
			let ic=r.tag('td',{atb:{dir:'c'}}).tag('a',{atb:{href:'/file/'+dash.file.dir.value+i,target:'_blank'}});
			if(ext==''){
				ic.tag('i',{atb:{ic:'_f074'},css:{fontSize:'64px',padding:'20px',color:'#ff5722'}});
				ic.tag('p',{html:i});
				let menu=r.tag('td',{atb:{dir:'r'}});
				menu.tag('button',{set:{dirs:i},atb:{class:'bt success'},html:'<i ic="_f075"></i>'}).on('click',function(){
					dash.file.dir.value+=this.dirs+'/';
					console.log(this.dirs);
					post({body:{
						list:1,
						dir:dash.file.dir.value
					}});
				});
			}else{
				if(ext=='jpg'||ext=='jpeg'||ext=='png'||ext=='gif'||ext=='webp'||ext=='ico'){
					ic.tag('img',{atb:{src:'/file/'+dash.file.dir.value+i},css:{width:'100%',maxWidth:'100px'}})
				}else{
					ic.tag('i',{atb:{ic:'_f127'},css:{fontSize:'64px',padding:'20px',color:'#aaa'}})
				}
				ic.tag('p',{html:i});
				let menu=r.tag('td',{atb:{dir:'r'}});
				menu.tag('button',{set:{file:i,text:menu.tag('input',{set:{value:'/file/'+dash.file.dir.value+i},atb:{class:'hide'}})},atb:{class:'bt success'},html:'<i ic="_f0ad"></i>'}).on('click',function(){
					copytxt(this.text);
				});
				menu.tag('button',{set:{file:i},atb:{class:'bt danger'},html:'<i ic="_f17f"></i>'}).on('click',function(){
					xsweet({
						file:this.file,
						job:'confirm',
						tbt1:'Delete',
						submit:function(sw){
							post({body:{
								del:sw.data.file,
								dir:dash.file.dir.value
							}})
						}
					})
				});
			}
		}
	},
	success:function(a){
		this.file.html('อัพโหลดไฟล์สำเร็จ: /'+a.file);
	},
	upload:function(){
		let p=this.page.html('');
		p.tag('p',{html:'ชื่อไฟล์'});
		let name=p.tag('input',{atb:{placeholder:'Name File...'}});
		p.tag('br');
		p.tag('p',{html:'เลือกไฟล์'});
		let file=p.tag('input',{atb:{type:'file',placeholder:'Name File...'}});
		p.tag('br');
		this.file=p.tag('p');
		p.tag('p').tag('button',{set:{file:file,iname:name},atb:{class:'bt success'},html:'<w ic="_f08a"></w>อัพโหลด'}).on('click',function(){
			var o=this.file.files;
			if(o[0]){
				post({body:{
					name:this.iname.value.trim(),
					file:o[0],
					dir:dash.file.dir.value
				}});
				this.iname.value='';
				this.file.value='';
			}else toast.error(' กรุณาเลือกไฟล์');
		});
	}
},
};

function _addload(a){
	if(typeof a.type=="string"&&window._utype!=a.type){
		window._utype=a.type;
		let menu=[
			['_f087','Login','login','post'],
		];
		if(a.type=='admin'){
			menu=[
				['_f0dc','Dashboard','dashboard','post'],
				['_f164','Database','mydb','post'],
				['_f074','File Manager','file','post'],
				['_f1d5','Profile','profile','post'],
				['_f0a6','Tools','tools','post'],
				['_f083','Logout','logout','post'],
			];
		}else if(a.type=='user'){
			menu=[
				['_f0dc','Dashboard','dashboard','post'],
				['_f1d5','Profile','profile','post'],
				['_f0a6','Tools','tools','post'],
				['_f083','Logout','logout','post'],
			];
		}
		var r='';
		for(x of menu)r+='<a method="'+x[3]+'" href="'+x[2]+'" title="'+x[1]+'"><i ic="'+x[0]+'"></i><span class="mmin icm">'+x[1]+'</span></a>';
		q('.menubox').html(r);
	}
	url=(url=location.pathname.split('/'))[url.length-1];
	qs('.menubox a').forEach(function(a){
		a.satb('class',a.gatb('href')==url?'active':'');
	});
}

function setstyle(css){
	if(typeof css=='string'){
		q('style').html(css);
		setCookie('style',base64.encode(css),1);
	}else{
		q('style').html('');
		setCookie('style','',1);
	}
	
}

(function(){
let obj=newhtml(q('body').tag('div'),"background\n.nav\n\twidth\n\t\t.boxnav\n\t\t\t.left\n\t\t\t\ta.logo(href='/')\n\t\t\t\t\ti(ic='_efff')\n\t\t\t\t\t.name\n\t\t\t\t\t\th1@name\n\t\t\t\t\t\tspan Dashboard\n\t\t\t\t.menu@mbox\n\t\t\t\t\t.menubox\n\t\t\t.right\n\t\t\t\ta@mode(ic='_f03e')\n\t\t\t\ta.full.mmin@menu(ic='_f0b1')\n\t\t\t\t\nibox\n\tpage\n\t\troot\n\t\tfooter\n\t\t\twidth\n\t\t\t\t(style='text-align:center;')\n\t\t\t\t\tp\n\t\t\t\t\t\ti(ic='_f180')\n\t\t\t\t\t\t|  R938 2022 | All Rights Reserved");
obj.name.html(_name);
obj.menu.on('click',function(){
	this.mbox.classList.toggle("show");
	this.satb('ic',this.mbox.classList.contains('show')?'_f00d':'_f0b1')
}).mbox=obj.mbox;
obj.mode.on('click',function(){
	q('body').classList.toggle("darkmode");
	setCookie('darkmode',q('body').classList.contains('darkmode')?1:0,30)
});
if(getCookie('darkmode')=='1')q('body').classList.add('darkmode');
q('head').tag('style',{html:base64.decode(getCookie('style'))});
curl_add('curl-api32.isorada.com');
curl_use=0;
}());

xopen(location.pathname);
load({status:200});
on(window,"popstate",playload);