let rqq={},http={
	0:'Request Canceled',
	400:'Bad Request',
	401:'Unauthorized',
	402:'Payment Required',
	403:'Forbidden',
	404:'Not found',
	405:'Method not allowed',
	406:'Not acceptable response', 
	407:'Proxy Authentication Required',
	408:'The server timed out',
	409:'Conflict',
	410:'The requested resource is gone',
	500:'Iternal server error',
	501:'Not Implemented',
	502:'Bad Gateway',
	503:'The server is unavailable',
	504:'The server, acting as a gateway',
	505:'HTTP Version Not Supported',
	508:'Resource Limit Is Reached',
	511:'Network Authentication Required',
	521:'Web server is down',
	525:'SSL Handshake Failed',
};
function q(a){
	a=document.querySelector(a);
	return a==null?0:xtool(a)
}
function qs(a){
	a=document.querySelectorAll(a);
	return a.length>0?(a.forEach(xtool),a):[]
}
function xtool(a){
	if(a.xtool!=1){
		a.remove=function(){this.parentNode.removeChild(this)};
		a.gatb=function(a){return this.getAttribute(a)};
		a.satb=function(a,b){this.setAttribute(a,b);return this};
		a.ratb=function(a){this.removeAttribute(a);return this};
		a.css=function(a,b){this.style[a]=b;return this};
		a.html=function(a){this.innerHTML=a;return this};
		a.on=function(a,b){on(this,a,b);return this};
		a.xnew=function(a){return xnew(this,a)};
		a.tag=function(a,b){return tag(this,a,b)};
		a.q=function(a){
			a=this.querySelector(a);
			return a==null?0:xtool(a)
		};
		a.qs=function(a){
			a=this.querySelectorAll(a);
			return a.length>0?(a.forEach(xtool),a):[]
		};
		a.xtool=1
	}
	return a
}

function tag(id,tag,set){
	var a=xnew(id,tag);
	if(typeof set=='object'){
		if(typeof set.html=="string"||typeof set.html=="number")a.innerHTML=set.html;
		var css=set.css;
		if(typeof css=="object")
			for(x in css)a.style[x]=css[x];
		var ss=set.set;
		if(typeof ss=="object")
			for(x in ss)a[x]=ss[x];
		var atb=set.atb;
		if(typeof atb=="object")
			for(x in atb)a.setAttribute(x,atb[x]);
	}
	return a
}
function xnew(a,b){
	var z=document.createElement(b);
	a.appendChild(z);return xtool(z)
}
function on(a,b,c){
	a.addEventListener?a.addEventListener(b,c,0):a.attachEvent?a.attachEvent("on"+b,c):a["on"+b]=c
}
function ihtml(str){
	let qq=/[a-zA-z0-9_-]/,s=0,m='',l='',h=0,g='',j='',v='',
	line=0,tag='',iclass='',id='',obj='',atb={},html='';
	for(x in str){
		let k=str[x];
		if(s==0&&k.search(/[\t\s]/)!=-1)line=x*1+1;
		else{
			if(s==0)s=1;
			
			if(s==1){
				if(k.search(qq)!=-1)tag+=k;
				else if(k=='|')tag=k;
				else if(k==' ')s=3;
				else s=2,m=k
			}else if(s==2){
				if(m!='('&&k==' ')s=3;
				else if(m=='.'){
					if(k.search(qq)!=-1)iclass+=(iclass!=''&&l=='.'?' ':'')+k;
					else m=k
				}else if(m=='('){
					if(h==0){
						if(k=='=')h=1;
						else if(k.search(qq)!=-1)j+=k;
						else if(k==',')(j!=''?atb[j]=v:0),h=0,g='',j='',v='';
						else if(k==')')m=k,(j!=''?atb[j]=v:0)
					}else if(h==1){
						if(g==''){
							if(k.search(/[\"\'\/]/)!=-1)g=k;
							else (j!=''?atb[j]=v:0),h=0,g='',j='',v=''
						}else{
							if(k==g)h=2;
							else v+=k
						}
					}else if(h==2){
						if(k==',')(j!=''?atb[j]=v:0),h=0,g='',j='',v='';
						else if(k==')')m=k,(j!=''?atb[j]=v:0)
					}
				}else if(m==')'){
					m=k,h=0,g='',j='',v=''
				}else if(m=='#'){
					if(k.search(qq)!=-1){
						if(l=='#')id=k;
						else id+=k;
					}else m=k;
				}else if(m=='@'){
					if(k.search(qq)!=-1){
						if(l=='@')obj=k;
						else obj+=k;
					}else m=k;
				}
			}else if(s==3){
				html=str.substring(x);
				break
			}
		}
		l=k
	}
	return {
		line:line,
		tag:tag==''?'div':tag,
		html:html,
		class:iclass,
		id:id,
		obj:obj,
		atb:atb
	}
}
function newhtml(id,i){
	id.innerHTML='';
	let s=i.split(/\n/),t={0:id},obj={};
	s.forEach(function(a){
		if(a!=''){
			let ss=ihtml(a);
			if(t.hasOwnProperty(ss.line)&&ss.tag.search(/\s/)==-1){
				if(ss.tag=='|'){
					t[ss.line].innerHTML+=ss.html
				}else{
					if(ss.tag=='new'){
						ss.atb.target='_blank';
						ss.tag='a'
					}else if(ss.tag=='post'){
						ss.atb.method='post';
						ss.tag='a'
					}else if(ss.tag=='get'){
						ss.atb.method='get';
						ss.tag='a'
					}else if(ss.tag=='cpost'){
						ss.atb.method='cpost';
						ss.tag='a'
					}else if(ss.tag=='cget'){
						ss.atb.method='cget';
						ss.tag='a'
					}
					let ntag=t[ss.line].tag(ss.tag,{atb:ss.atb});
					if(ss.html!='')ntag.html(ss.html);
					if(ss.class!='')ntag.satb('class',ss.class);
					if(ss.id!='')ntag.satb('id',ss.id);
					t[ss.line+1]=ntag;
					if(ss.obj!='')obj[ss.obj]=ntag;
				}
			}
		}
	});
	return obj
}

var barload=tag(document.body,'barload',{
	set:{
		bar:function(a){
			if(a>100)a=100;
			else if(a<0)a=0;
			this.css("left","")
			.css("right","")
			.css("background",a>99?"#4caf50":"")
			.css("width",a+"%");
			clearTimeout(this.time)
		},
		start:function(){
			this.p=40;
			this.bar(this.p);
			clearInterval(this.uload);
			this.uload=setInterval(function(a){
				a.p+=5;
				a.bar(a.p);
				if(a.p>80)clearInterval(a.uload)
			},600,this)
		},
		close:function(a){
			this.css("background",a=="ok"?"#4caf50":"#f44336")
			.css("left","")
			.css("right","")
			.css("width","100%");
			clearInterval(this.uload);
			if(a=="ok")this.time=setTimeout(function(a){
				a.css("width","0%")
				.css("right","0")
				.css("left","unset");
			},400,this)
		}
	}
});
var toast=tag(document.body,'toast',{
	set:{
		option:{
			timeout:5,
			btclose:1,
			click:1,
			top:'102px',
			right:'20px'
		},
		set:function(a,b,s){
			this.css("top",this.option.top)
			.css("right",this.option.right)
			.css("left",this.option.left)
			.css("bottom",this.option.bottom);
			if(typeof s=="object")this.load(s);
			
			var c="#2196f3",t="#fff",i="_f0f9",ic="#c0e2ff";
			if(a=='success'){c='#4caf50';t="#fff";i="_f00c";ic="#87ff8c";}
			else if(a=='error'){c='#ff5722';t="#fff";i="_f0fa";ic="#ffded3";}
			
			var id=this.tag('ms',{
				css:{background:c,color:t},
				set:{cc:1,r:{},del:function(){
					this.cc=0;
					clearTimeout(this.out);
					this.remove()
				}}
			});
			id.tag('w',{css:{color:ic},atb:{ic:i}});
			let html=id.tag('span',{html:b});
			
			var r={};
			
			if(this.option.btclose){
				r=id.tag('i',{atb:{ic:'_f00d'},set:{toast:id}}).on('click',function(){
					if(this.toast.cc){
						this.toast.remove();
						this.toast.cc=0;
					}
					clearTimeout(this.toast.out);
					
				});
				id.r=r;
			}
			if(this.option.click){
				id.on('click',function(){
					clearTimeout(this.out)
				})
			}
			if(this.option.timeout>0)id.out=setTimeout(function(a){
				if(a){
					a.css("opacity",0);
					setTimeout(function(a){
						if(a.cc)a.cc=0,a.remove()
					},600,a)
				}
			},this.option.timeout*1000,id);
			return html
		},
		success:function(a,b){
			return this.set('success',a,b)
		},
		error:function(a,b){
			return this.set('error',a,b)
		},
		text:function(a,b){
			return this.set('',a,b)
		},
		load:function(a){
			for(x in a)this.option[x]=a[x]
		},
		clear:function(){
			qs("toast ms").forEach(function(a){
				clearTimeout(a.out);
				a.remove();
				a.cc=0
			});
		}
	}
});

function rq(a){
	var z=window.XMLHttpRequest?(new XMLHttpRequest()):(new ActiveXObject("Microsoft.XMLHTTP"));
	var b=["load","end"];
	for(x in b)
		z[b[x]]=typeof a[b[x]]=="function"?a[b[x]]:function(){};
	if(typeof a.add=="object")
		for(x in a.add)z[x]=a.add[x];

	z.onreadystatechange=function(){
		if(this.readyState==4){
			this.load(this.status==200?this.response:{status:this.status});
			this.end(this);
		}
	};
	z.onerror=function(){this.load({status:this.status});this.end(this)};
	z.ontimeout=function(){this.load({status:408});this.end(this)};

	if(a.url!=""){
		z.open(typeof a.set=="string"?a.set:"GET",a.url,1);

		if(typeof a.body!="undefined"){
			var c=a.body,xhr='',form=new FormData(),by=0;
			for(x in c){
				form.append(x,c[x]);
				
				xhr+=(xhr==''?'':'&')+encodeURIComponent(x)+(c[x]==''?'':'='+encodeURIComponent(c[x]));
				if(typeof c[x]=='object')by=1;
			}
			if(by){
				a.body=form
			}else{
				a.body=xhr;
				z.setRequestHeader('Content-Type','application/x-www-form-urlencoded')
			}
		}else a.body="";

		z.send(a.body)
	}
	return z
}
function post(a){
	if(typeof a.body!='object')a.body={};
	a.body.ref=_ref;
	barload.start();
	if(rqq&&typeof rqq.abort=="function")rqq.abort();
	if(typeof a.url!='string')a.url=window.location.href;
	if(typeof a.load!='function')a.load=load;
	a.set="POST";
	
	var xhr=rq(a);
	if(!a.new)rqq=xhr;
	return xhr;
}
function get(a){
	barload.start();
	if(rqq&&typeof rqq.abort=="function")rqq.abort();
	if(typeof a.url!='string')a.url=window.location.href;
	if(typeof a.load!='function')a.load=load;
	var xhr=rq(a);
	if(!a.new)rqq=xhr;
	return xhr;
}
function postloop(a){
	return {
		rq:{},
		body:[],
		url:'',
		
		start:function(){
			if(this.body.length>0){
				var bb=this.body[0],nn=[];
				for(var i=1;i<this.body.length;i++)
					nn[nn.length]=this.body[i];
				if(this.rq&&typeof this.rq.abort=="function")this.rq.abort();
				barload.start();
				this.rq=rq({
					url:this.url,
					set:"POST",
					body:bb,
					load:load,
					end:function(a){
						a.xloop.start();
						
					}
				});
				this.rq.xloop=this;
				this.body=nn;
			}
		},
		
	};
}
let server_curl=[],curl_use=0;
function curl_add(a){
	if(typeof a=='string')server_curl.push('https://'+a+'/');
	else if(typeof a=='object')
		for(x in a)
			server_curl.push('https://'+a[x]+'/');
}
function curl(url,script,add,newtab){
	let op={url:url};
	if(typeof url=="object")op=url;
	let s={code:JSON.stringify(op)};
	if(typeof script=='string')s.run=script;
	if(typeof add=='object')s.add=JSON.stringify(add);
	
	
	if(server_curl.length<=0)return toast.error('Not have server_curl');
	else if(!server_curl.hasOwnProperty(curl_use))return toast.error('Not have server_curl['+curl_use+']');
	post({
		new:newtab===1?1:0,
		url:server_curl[curl_use],
		body:s
	})
}

function itoggle(a){
	let toggle=a.gatb("toggle");
	if(typeof toggle=="string"&&q(toggle)){
		a.toggle=q(toggle).css('height',0).ratb('id');
		a.toggle.classList.add('toggle');
		var group=a.gatb("group");
		if(typeof group=="string"){
			a.group=group;
			if(!togglelist[group])togglelist[group]=[];
			var tog=togglelist[group];
			tog[tog.length]=a;
		}
		a.on('click',function(){
			event.preventDefault();
			var a=this.toggle;
			clearTimeout(a.fout);
			if(a.style.height=="0px"){
				var tog=togglelist[this.group];
				if(tog)tog.forEach(function(id){
					var bb=id.toggle;
					clearTimeout(bb.fout);
					if(bb.style.height!="0px"){
						bb.css("height",bb.scrollHeight+"px")
						.fout=setTimeout(function(bb){bb.css("height",0)},1,bb);
					}
				});
				a.css("height",a.scrollHeight+"px")
				.fout=setTimeout(function(a){a.css("height",'')},400,a);
			}else a.css("height",a.scrollHeight+"px")
			.fout=setTimeout(function(a){a.css("height",0)},1,a);
		});
		
		a.ratb("toggle").ratb("group");
		if(a.gatb("load")=="true")a.ratb("load").click();
	}
}
function ilink(a){
	let method=a.gatb("method");
	if(typeof method=="string"){
		let u=a.gatb("href");
		a.ratb("method");
		if(method=="post"){
			a.on("click",function(e){
				e.preventDefault();
				scr(0);
				var host=this.gatb('href');
				window.history.pushState("","",host);
				post({url:host})
			})
		}else if(method=="get"){
			a.on("click",function(e){
				e.preventDefault();
				scr(0);
				var host=this.gatb('href');
				window.history.pushState("","",host);
				get({url:host})
			})
		}else if(method=="cpost"){
			a.iurl=a.gatb("url");
			a.on("click",function(e){
				e.preventDefault();
				scr(0);
				var host=this.gatb('href');
				window.history.pushState("","",host);
				post({url:this.iurl})
			}).ratb("url")
		}else if(method=="cget"){
			a.iurl=a.gatb("url");
			a.on("click",function(e){
				e.preventDefault();
				scr(0);
				var host=this.gatb('href');
				window.history.pushState("","",host);
				get({url:this.iurl})
			}).ratb("url")
		}
	}
}

function xsweet(a){
	var s=new sweet;
	if(typeof a.job=="string"){
		var j=a.job;
		if(typeof a.submit!='function')a.submit=typeof a.submit=='string'?eval("("+a.submit+")"):function(){};
		if(typeof a.cancel!='function')a.cancel=typeof a.cancel=='string'?eval("("+a.cancel+")"):function(){};
		if(j=="textarea"){
			a.fbt1=function(sw){sw.data.submit(sw.content.q('textarea').value,sw)};
			a.fbt2=function(sw){sw.data.cancel(sw)};
			a.f=function(sw){
				var a=sw.content.tag('textarea');
				if(sw.data.hasOwnProperty('placeholder'))a.satb('placeholder',sw.data.placeholder);
				if(typeof sw.data.value!='undefined')a.value=sw.data.value;
				setTimeout(function(a){a.focus()},1,a)
			};
			if(!a.hasOwnProperty('bt1'))a.bt1=1;
			if(!a.hasOwnProperty('title'))a.title='Input';
			if(!a.hasOwnProperty('tbt1'))a.tbt1="Submit";
		}else if(j=="input"){
			a.fbt1=function(sw){sw.data.submit(sw.content.q('input').value,sw)};
			a.fbt2=function(sw){sw.data.cancel(sw)};
			a.f=function(sw){
				var a=sw.content.tag('input',{set:{a:sw}}).on('keypress',function(e){
					if(e.which==13){
						let sw=this.a;
						sw.data.submit(this.value,sw);
						sw.close()
					}
				});
				if(sw.data.hasOwnProperty('placeholder'))a.satb('placeholder',sw.data.placeholder);
				if(typeof sw.data.value!='undefined')a.value=sw.data.value;
				setTimeout(function(a){a.focus()},1,a)
			};
			if(!a.hasOwnProperty('bt1'))a.bt1=1;
			if(!a.hasOwnProperty('title'))a.title='Input';
			if(!a.hasOwnProperty('tbt1'))a.tbt1="Submit";
		}else if(j=="confirm"){
			a.fbt1=function(a){a.data.submit(a)};
			a.fbt2=function(a){a.data.cancel(a)};
			if(!a.hasOwnProperty('bt1'))a.bt1=1;
			if(!a.hasOwnProperty('icon'))a.icon="question";
			if(!a.hasOwnProperty('title'))a.title="Are you sure?";
			if(!a.hasOwnProperty('tbt1'))a.tbt1="Confirm";
		}
	}
	return s.set(a)
}
function sweet(){
	let main=q('body').tag('div');
	let a=newhtml(main,".sweet-fix@fix(style='display:none;background:rgba(0,0,0,0);')\n\t.sweet-box@box(style='transform:scale(0);')\n\t\t.sweet-icon@icon\n\t\t.sweet-header@title\n\t\t.sweet-content@content\n\t\t.sweet-actions@actions\n\t\t\t.sweet-loader@load(style='display:none;')\n\t\t\tbutton.sweet-bt.sweet-c1@bt1(style='display:none;')\n\t\t\tbutton.sweet-bt.sweet-c2@bt2");
	
	a.time=0;
	a.mode='close';
	a.data={};
	a.my=main;
	a.f=function(){};
	a.fbt1=function(){};
	a.fbt2=function(){};

	a.bt1.on('click',function(){
		let i=this.a;
		i.fbt1(i);
		this.a[this.a.mode]()
	}).a=a;
	a.bt2.on('click',function(){
		let i=this.a;
		i.fbt2(i);
		this.a[this.a.mode]()
	}).a=a;
	a.hide=function(){
		clearTimeout(this.time);
		q('body').css('overflow','');
		this.box.css('transform','scale(0)');
		this.fix.css('background','rgba(0,0,0,.0)');
		this.time=setTimeout(function(a){
			a.fix.css('display','none')
		},100,this)
	};
	a.close=function(){
		this.hide();
		setTimeout(function(a){a.my.remove()},100,this)
	};
	a.y=function(a,b){
		if(typeof this.data[a]!="undefined") return this.data[a];
		else return b
	};
	a.set=function(a){
		if(typeof a=="object")this.data=a;
		this.hide();
		if(a.mode)this.mode=a.mode;
		this.fbt1=this.y('fbt1',function(){});
		this.fbt2=this.y('fbt2',function(){});
		this.f=this.y('f',function(){});
		this.load.css('display',this.y('load',0)?'':'none');
		this.bt1.css('display',this.y('bt1',0)?'':'none');
		this.bt2.css('display',this.y('bt2',1)?'':'none');
		this.bt1.html(this.y('tbt1','OK'));
		this.bt2.html(this.y('tbt2','Cancel'));
		
		if(this.y('bt1',0))setTimeout(function(a){a.focus()},1,this.bt1);
		else if(this.y('bt2',1))setTimeout(function(a){a.focus()},1,this.bt2);
		
		var icon=this.y('icon','');
		if(icon!=''){
			var ui={
				success:['_f053','#28a745'],
				info:['_f055','#17a2b8'],
				warning:['_f06a','#ffc107'],
				error:['_f052','#dc3545'],
				question:['_f054','#007bff']
			};
			var uc=ui.hasOwnProperty(icon)?ui[icon]:icon.split("|");
			icon='<i style="color:'+(uc.hasOwnProperty(1)?uc[1]:"#fff")+'" ic="'+uc[0]+'"></i>';
		}
		this.icon.html(icon);
		this.title.html(this.y('title',''));
		this.content.html(this.y('content',''));
		this.fix.css('display','');
		this.fix.css('background','');
		this.box.css('transform','');
		
		q('body').css('overflow','hidden');
		clearTimeout(this.time);
		
		this.f(this);
		return this
	};
	return a
};

function searchlist(id,submit,show){
	id.input.ilist=id.list;
	id.input.submit=submit;
	id.input.show=show;
	id.input.chqq=function(){
		let i=0,l=0,word=new RegExp(this.value,'i'),show=this.show,
		ss1=[],ss2=[],mn=function(a){
			if(show>l){
				a.classList.add('show');
				a.html(a.innerText.replace(word,function(a){
					return '<span style="color:#ff5722;">'+a+'</span>'
				}));
				l++
			}
		};
		this.ilist.qs('li').forEach(function(a){
			if(a.innerText.search(word)==0)ss1.push(a);
			else if(a.innerText.search(word)!=-1)ss2.push(a);
			a.classList.remove('show');
			a.classList.remove('active');
			a.html(a.innerText)
		});
		if(ss1.length>0){
			ss1.forEach(mn),
			i=ss1.length;
		}else if(ss2.length>0){
			ss2.forEach(mn),
			i=ss2.length;
		}
		
		this.ilist.classList.remove('close');
		this.ch14=0
	};
	id.input.ch12=1;
	id.input.on('click',function(){
		if(this.all)this.select();
		this.all=0
	}).on('focusout',function(){
		if(this.ch12===1)this.ilist.classList.add('close');
		this.ch14=1;
		this.all=1
	}).on('focusin',function(){
		this.chqq()
	}).on('keyup',function(e){
		let code=e.keyCode;
		if(code===13){
			let p=this.ilist.q('li.active');
			if(p!==0)p.click();
			else this.submit(this.value)
		}else if(code===38||code===40){
			let li=this.ilist.qs('li.show'),sc='',i=0,hh=0;
			li.forEach(function(a,b){
				if(a.classList.contains('active')){
					a.classList.remove('active');
					if(code===38){
						if(b==0)i=li.length-1;
						else i=b-1
					}else if(code===40){
						if(b==li.length-1)i=0;
						else i=b+1
					}
					sc=li[i]
				}else if(sc=='')hh+=a.scrollHeight
			});
			if(sc!='')sc.classList.add('active');
			else if(li.length>0)sc=li[0],li[0].classList.add('active'),i=0;
			
			if(li.length>0)this.value=sc.innerText;
		}else this.chqq()
	});

	id.send.val=id.input;
	id.send.submit=submit;
	id.send.on('click',function(){
		this.submit(this.val.value)
	});

	id.list.val=id.input;
	id.list.submit=submit;
	id.list.on('mouseout',function(){
		this.val.ch12=1;
		if(this.val.ch14==1)this.classList.add('close');
	}).on('mousemove',function(){
		this.val.ch12=0
	}).on('touchmove',function(){
		this.val.ch12=0
	}).on('touchend',function(){
		this.val.ch12=1;
		if(this.val.ch14==1)this.classList.add('close');
	}).qs('li').forEach(function(a){
		a.submit=submit;
		a.val=id.input;
		a.on('click',function(){
			this.ilist.classList.add('close');
			this.val.value=this.innerText
		}).on('mousemove',function(){
			let r=this;
			r.ilist.qs('li.active').forEach(function(a){
				if(a.classList.contains('active')&&r!=a)a.classList.remove('active');
			});
			if(!this.classList.contains('active'))this.classList.add('active');
		}).on('mouseout',function(){
			if(this.classList.contains('active'))this.classList.remove('active');
		}).ilist=id.list
	})
}
function itime(c){
	if(!c.hasOwnProperty('h'))c.h={};
	if(!c.hasOwnProperty('m'))c.m={};
	if(!c.hasOwnProperty('s'))c.s={};
	if(!c.hasOwnProperty('d'))c.d={};
	let uptime=function(i,uptime){
		var t=new Date,z='0';
		var day=['Sun','Mon','Tues','Wednes','Thurs','Fri','Satur'][t.getDay()]+'day';
		var d=t.getDate(),m=t.getMonth()+1,y=t.getFullYear();
		if(d<10)d=z+d;
		if(m<10)m=z+m;
		var th=t.getHours(),tm=t.getMinutes(),ts=t.getSeconds();
		if(th<10)th=z+th;
		if(tm<10)tm=z+tm;
		if(ts<10)ts=z+ts;
		let dd=day+' '+d+'/'+m+'/'+y;
		if(i.d.innerHTML!=dd)i.d.innerHTML=dd;
		if(typeof i.dot=='object'){
			let dot=(ts*1)%2==0?'':'transparent',io=[];
			i.dot.forEach(function(id){
				if(typeof id.css=='function'&&id.isConnected)io.push(id),id.css('color',dot);
			});
			i.dot=io
		}
		
		if(i.h.innerHTML!=th)i.h.innerHTML=th;
		if(i.m.innerHTML!=tm)i.m.innerHTML=tm;
		if(i.s.innerHTML!=ts)i.s.innerHTML=ts;
		if(i.h.isConnected||i.m.isConnected||i.s.isConnected||i.d.isConnected)
			setTimeout(uptime,1000,i,uptime)
	};
	uptime(c,uptime)
}
function gettime(){
	return ((new Date).getTime()/1000).toFixed()*1;
}
function jsons(a){
	try{
		return JSON.parse(a)
	}catch(e){
		return {}
	}
}
function escapeHtml(a){
	if(typeof a=="string")return a.replace(/[<>]/g,function(m){return {
		'<':'&lt;',
		'>':'&gt;',
	}[m]})
}
function copytxt(cptxt){
	if(typeof cptxt=='object'&&cptxt.value.length>0){
		cptxt.select();
		cptxt.setSelectionRange(0,cptxt.value.length);
		navigator.clipboard.writeText(cptxt.value);
		toast.success('คัดลอกสำเร็จ')
	}else{
		toast.error('คัดลอกไม่สำเร็จ')
	}
}
function formatSizeUnits(b){
	if(b>=1073741824)b=(b/1073741824).toFixed(2)+" GB";
	else if(b>=1048576)b=(b/1048576).toFixed(2)+" MB";
	else if(b>=1024)b=(b/1024).toFixed(2)+" KB";
	else if(b>1)b=b+" bytes";
	else if(b==1)b=b+" byte";
	else b="0 bytes";
	return b;
}
function number_format(number,a,b,c) {
	if(number==null)return number;
	if(!a){
		var len=number.toString().split('.').length;
		a=len>1?len:0;
	}
	if(!b)b='.';
	if(!c)c=',';
	number=parseFloat(number).toFixed(a);
	number=number.replace(".",b);
	var splitNum=number.split(b);
	splitNum[0]=splitNum[0].replace(/\B(?=(\d{3})+(?!\d))/g,c);
	number=splitNum.join(b);

	return number;
}
function strstr(str,word,mode){
	str+="";
	let pos=str.indexOf(word); 
	if(pos==-1){
		return false;
	}else{
		return mode?str.substr(0,pos):str.slice(pos);
	}
}
function setCookie(name,value,exp,path){
	const d=new Date();
	if(typeof path=='undefined')path='/';
	d.setTime(d.getTime()+(exp*24*60*60*1000));
	let expires="expires="+d.toUTCString();
	document.cookie=name+"="+value+";"+expires+";path="+path;
}
function getCookie(name){
	name=name+"=";
	let ca=document.cookie.split(';');
	for(let i=0;i<ca.length;i++){
		let c=ca[i];
		while(c.charAt(0)==' ')c=c.substring(1);
		if(c.indexOf(name)==0)return c.substring(name.length,c.length);
	}
	return "";
}
function pagination(a,e,n,r,m){
	if(typeof n=='undefined')n='';
	if(typeof r=='undefined')r='';
	var t="",
	o=unescape("%22"),
	s=1*e,
	f=1*a,
	i="<a "+(typeof m=="string"?m:'method=post')+" href="+o+n,
	c=function(a){return a?" class=active":""};
	
	f>1&&(t+=i+(f-1)+r+o+">‹&nbsp;Prev</a>");
	if(s>7){
		f-2>1&&(t+=i+"1"+r+o+">1</a>"),
		f-3>1&&(t+="<a>...</a>");
		
		for(var p=f-2>1?f-2:1;p<=(f+2>s?s:f+2);p++)
			t+=i+p+r+o+c(p==f)+">"+p+"</a>";
		
		f+3<s&&(t+="<a>...</a>"),
		f+2<s&&(t+=i+s+r+o+">"+s+"</a>")
	}else{
		for(p=1;p<=s;p++)
			t+=i+p+r+o+c(p==f)+">"+p+"</a>";
	}
	f<s&&(t+=i+(f+1)+r+o+">Next&nbsp;›</a>");
	return t
}

function xopen(a){
	window.history.pushState("","",a);
	playload(a)
}
function scr(a){
	if(q('page')!=0)q('page').scrollTo({top:a,behavior:'smooth'})
}
function playload(a){
	if(rqq&&typeof rqq.abort=="function")rqq.abort();
	rqq=post({
		url:typeof a=="string"?a:window.location.href
	})
}
function getplayload(a){
	if(rqq&&typeof rqq.abort=="function")rqq.abort();
	rqq=get({
		url:typeof a=="string"?a:window.location.href
	})
}
function load(a){
	if(typeof a=="string"){
		let as=jsons(a);
		if(!as.hasOwnProperty('status')){
			let ssh=a.match(/<script\b[^>]*>let \_load\=([\s\S]*?)<\/script>/);
			if(ssh.length==2)a=jsons(ssh[1]);
		}else a=as;
	}
	if(typeof _name=='undefined')_name='R938';
	
	window.togglelist={};
	if(a.status==200){
		barload.close("ok");
		if(a.sweet)(new sweet).set(a.sweet);
		if(a.xsweet)xsweet(a.xsweet);
		if(a.toast){
			let i=a.toast[0];
			if(i=='0')i='error';
			else if(i=='1')i='success';
			else i='info';
			toast.set(i,a.toast.substr(1))
		}
		if(typeof a.root=="object"){
			var b=a.root;
			if(b.etitle)document.title=escapeHtml(_name+' | '+b.etitle);
			if(b.title)document.title=escapeHtml(b.title+' - '+_name);
			if(typeof b.body=="string")q("root").html(b.body);
			if(b.script)eval(b.script);
		}
		if(typeof _addload=='function')_addload(a)
	}else{
		barload.close();
		var err=typeof a.status=='number'?a.status:404,
		txt=http.hasOwnProperty(err)?http[err]:'Error';
		
		newhtml(toast.error('',{timeout:6}),'b(style="color:#333;") '+err+' \nspan(style="color:#313131;") '+txt);
		if(typeof page_err=="function")page_err(err,typeof this.responseURL=='undefined'?location.pathname:this.responseURL);
		document.title=escapeHtml(err+' '+txt+' - '+_name)
	}
	qs("a[method]").forEach(ilink);
	qs("[toggle]").forEach(itoggle);
}

let base64={
	str:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
	encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=(function(e){e=e.replace(/\r\n/g,"\n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t}(e));while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this.str.charAt(s)+this.str.charAt(o)+this.str.charAt(u)+this.str.charAt(a)}return t},
	decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9\+\/\=]/g,"");while(f<e.length){s=this.str.indexOf(e.charAt(f++));o=this.str.indexOf(e.charAt(f++));u=this.str.indexOf(e.charAt(f++));a=this.str.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=(function(e){var t="";var n=0;var r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}(t));return t}
};
let md5=function(){
	var n=function(n){return function(n){for(var r,t="0123456789abcdef",e="",o=0;o<n.length;o++)r=n.charCodeAt(o),e+=t.charAt(r>>>4&15)+t.charAt(15&r);return e}(function(n){for(var r="",t=0;t<32*n.length;t+=8)r+=String.fromCharCode(n[t>>5]>>>t%32&255);return r}(function(n,r){n[r>>5]|=128<<r%32,n[14+(r+64>>>9<<4)]=r;for(var i=1732584193,c=-271733879,a=-1732584194,h=271733878,g=0;g<n.length;g+=16){var v=i,d=c,l=a,A=h;c=u(c=u(c=u(c=u(c=o(c=o(c=o(c=o(c=e(c=e(c=e(c=e(c=t(c=t(c=t(c=t(c,a=t(a,h=t(h,i=t(i,c,a,h,n[g+0],7,-680876936),c,a,n[g+1],12,-389564586),i,c,n[g+2],17,606105819),h,i,n[g+3],22,-1044525330),a=t(a,h=t(h,i=t(i,c,a,h,n[g+4],7,-176418897),c,a,n[g+5],12,1200080426),i,c,n[g+6],17,-1473231341),h,i,n[g+7],22,-45705983),a=t(a,h=t(h,i=t(i,c,a,h,n[g+8],7,1770035416),c,a,n[g+9],12,-1958414417),i,c,n[g+10],17,-42063),h,i,n[g+11],22,-1990404162),a=t(a,h=t(h,i=t(i,c,a,h,n[g+12],7,1804603682),c,a,n[g+13],12,-40341101),i,c,n[g+14],17,-1502002290),h,i,n[g+15],22,1236535329),a=e(a,h=e(h,i=e(i,c,a,h,n[g+1],5,-165796510),c,a,n[g+6],9,-1069501632),i,c,n[g+11],14,643717713),h,i,n[g+0],20,-373897302),a=e(a,h=e(h,i=e(i,c,a,h,n[g+5],5,-701558691),c,a,n[g+10],9,38016083),i,c,n[g+15],14,-660478335),h,i,n[g+4],20,-405537848),a=e(a,h=e(h,i=e(i,c,a,h,n[g+9],5,568446438),c,a,n[g+14],9,-1019803690),i,c,n[g+3],14,-187363961),h,i,n[g+8],20,1163531501),a=e(a,h=e(h,i=e(i,c,a,h,n[g+13],5,-1444681467),c,a,n[g+2],9,-51403784),i,c,n[g+7],14,1735328473),h,i,n[g+12],20,-1926607734),a=o(a,h=o(h,i=o(i,c,a,h,n[g+5],4,-378558),c,a,n[g+8],11,-2022574463),i,c,n[g+11],16,1839030562),h,i,n[g+14],23,-35309556),a=o(a,h=o(h,i=o(i,c,a,h,n[g+1],4,-1530992060),c,a,n[g+4],11,1272893353),i,c,n[g+7],16,-155497632),h,i,n[g+10],23,-1094730640),a=o(a,h=o(h,i=o(i,c,a,h,n[g+13],4,681279174),c,a,n[g+0],11,-358537222),i,c,n[g+3],16,-722521979),h,i,n[g+6],23,76029189),a=o(a,h=o(h,i=o(i,c,a,h,n[g+9],4,-640364487),c,a,n[g+12],11,-421815835),i,c,n[g+15],16,530742520),h,i,n[g+2],23,-995338651),a=u(a,h=u(h,i=u(i,c,a,h,n[g+0],6,-198630844),c,a,n[g+7],10,1126891415),i,c,n[g+14],15,-1416354905),h,i,n[g+5],21,-57434055),a=u(a,h=u(h,i=u(i,c,a,h,n[g+12],6,1700485571),c,a,n[g+3],10,-1894986606),i,c,n[g+10],15,-1051523),h,i,n[g+1],21,-2054922799),a=u(a,h=u(h,i=u(i,c,a,h,n[g+8],6,1873313359),c,a,n[g+15],10,-30611744),i,c,n[g+6],15,-1560198380),h,i,n[g+13],21,1309151649),a=u(a,h=u(h,i=u(i,c,a,h,n[g+4],6,-145523070),c,a,n[g+11],10,-1120210379),i,c,n[g+2],15,718787259),h,i,n[g+9],21,-343485551),i=f(i,v),c=f(c,d),a=f(a,l),h=f(h,A)}return[i,c,a,h]}(function(n){for(var r=Array(n.length>>2),t=0;t<r.length;t++)r[t]=0;for(t=0;t<8*n.length;t+=8)r[t>>5]|=(255&n.charCodeAt(t/8))<<t%32;return r}(n),8*n.length)))};function r(n,r,t,e,o,u){return f(function(n,r){return n<<r|n>>>32-r}(f(f(r,n),f(e,u)),o),t)}function t(n,t,e,o,u,f,i){return r(t&e|~t&o,n,t,u,f,i)}function e(n,t,e,o,u,f,i){return r(t&o|e&~o,n,t,u,f,i)}function o(n,t,e,o,u,f,i){return r(t^e^o,n,t,u,f,i)}function u(n,t,e,o,u,f,i){return r(e^(t|~o),n,t,u,f,i)}function f(n,r){var t=(65535&n)+(65535&r);return(n>>16)+(r>>16)+(t>>16)<<16|65535&t}return function(r){r instanceof Uint8Array||(r=(new TextEncoder).encode("string"==typeof r?r:JSON.stringify(r)));for(var t=[],e=new Uint8Array(r),o=0,u=e.byteLength;o<u;o++)t.push(String.fromCharCode(e[o]));return n(t.join(""))}
}();
(function(){
	let i,css='',m='0123456789abcdef'.split(''),s='efff'.split('');
	for(i=0;i<486;i++){
		let font=s.join('');
		css+='[ic="_'+font+'"]:before{content:"\\'+font+'";}';
		if(m.indexOf(s[3])+1>15){
			s[3]=m[0];
			if(m.indexOf(s[2])+1>15){
				s[2]=m[0];
				if(m.indexOf(s[1])+1>15){
					s[1]=m[0];
					if(m.indexOf(s[0])+1>15)s[0]=m[0];
					else s[0]=m[m.indexOf(s[0])+1]
				}else s[1]=m[m.indexOf(s[1])+1]
			}else s[2]=m[m.indexOf(s[2])+1]
		}else s[3]=m[m.indexOf(s[3])+1]
	}
	q('head').tag('style',{html:css})
}());